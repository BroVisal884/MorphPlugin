package com.morphplugin.morph;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Entity;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;

import java.util.*;

public class MorphManager {

    private final MorphPlugin plugin;
    // Map of player UUID -> their current morph entity type
    private final Map<UUID, EntityType> morphedPlayers = new HashMap<>();
    // Map of player UUID -> the disguise entity
    private final Map<UUID, Entity> disguiseEntities = new HashMap<>();

    // All morphable mob types
    public static final List<EntityType> MORPHABLE_MOBS = new ArrayList<>();

    static {
        // Passive mobs
        MORPHABLE_MOBS.add(EntityType.COW);
        MORPHABLE_MOBS.add(EntityType.PIG);
        MORPHABLE_MOBS.add(EntityType.SHEEP);
        MORPHABLE_MOBS.add(EntityType.CHICKEN);
        MORPHABLE_MOBS.add(EntityType.HORSE);
        MORPHABLE_MOBS.add(EntityType.DONKEY);
        MORPHABLE_MOBS.add(EntityType.MULE);
        MORPHABLE_MOBS.add(EntityType.RABBIT);
        MORPHABLE_MOBS.add(EntityType.WOLF);
        MORPHABLE_MOBS.add(EntityType.CAT);
        MORPHABLE_MOBS.add(EntityType.OCELOT);
        MORPHABLE_MOBS.add(EntityType.FOX);
        MORPHABLE_MOBS.add(EntityType.PANDA);
        MORPHABLE_MOBS.add(EntityType.POLAR_BEAR);
        MORPHABLE_MOBS.add(EntityType.TURTLE);
        MORPHABLE_MOBS.add(EntityType.PARROT);
        MORPHABLE_MOBS.add(EntityType.BEE);
        MORPHABLE_MOBS.add(EntityType.MOOSHROOM);
        MORPHABLE_MOBS.add(EntityType.LLAMA);
        MORPHABLE_MOBS.add(EntityType.TRADER_LLAMA);
        MORPHABLE_MOBS.add(EntityType.VILLAGER);
        MORPHABLE_MOBS.add(EntityType.WANDERING_TRADER);
        MORPHABLE_MOBS.add(EntityType.IRON_GOLEM);
        MORPHABLE_MOBS.add(EntityType.SNOW_GOLEM);
        MORPHABLE_MOBS.add(EntityType.BAT);
        MORPHABLE_MOBS.add(EntityType.SQUID);
        MORPHABLE_MOBS.add(EntityType.GLOW_SQUID);
        MORPHABLE_MOBS.add(EntityType.COD);
        MORPHABLE_MOBS.add(EntityType.SALMON);
        MORPHABLE_MOBS.add(EntityType.PUFFERFISH);
        MORPHABLE_MOBS.add(EntityType.TROPICAL_FISH);
        MORPHABLE_MOBS.add(EntityType.DOLPHIN);
        MORPHABLE_MOBS.add(EntityType.AXOLOTL);
        MORPHABLE_MOBS.add(EntityType.FROG);
        MORPHABLE_MOBS.add(EntityType.TADPOLE);
        MORPHABLE_MOBS.add(EntityType.ALLAY);
        MORPHABLE_MOBS.add(EntityType.SNIFFER);
        MORPHABLE_MOBS.add(EntityType.CAMEL);
        MORPHABLE_MOBS.add(EntityType.ARMADILLO);

        // Neutral mobs
        MORPHABLE_MOBS.add(EntityType.SPIDER);
        MORPHABLE_MOBS.add(EntityType.CAVE_SPIDER);
        MORPHABLE_MOBS.add(EntityType.ENDERMAN);
        MORPHABLE_MOBS.add(EntityType.ZOMBIE_PIGMAN); // Zombified Piglin
        MORPHABLE_MOBS.add(EntityType.PIGLIN);
        MORPHABLE_MOBS.add(EntityType.GOAT);

        // Hostile mobs
        MORPHABLE_MOBS.add(EntityType.ZOMBIE);
        MORPHABLE_MOBS.add(EntityType.ZOMBIE_VILLAGER);
        MORPHABLE_MOBS.add(EntityType.HUSK);
        MORPHABLE_MOBS.add(EntityType.DROWNED);
        MORPHABLE_MOBS.add(EntityType.SKELETON);
        MORPHABLE_MOBS.add(EntityType.STRAY);
        MORPHABLE_MOBS.add(EntityType.WITHER_SKELETON);
        MORPHABLE_MOBS.add(EntityType.CREEPER);
        MORPHABLE_MOBS.add(EntityType.SLIME);
        MORPHABLE_MOBS.add(EntityType.MAGMA_CUBE);
        MORPHABLE_MOBS.add(EntityType.BLAZE);
        MORPHABLE_MOBS.add(EntityType.GHAST);
        MORPHABLE_MOBS.add(EntityType.WITCH);
        MORPHABLE_MOBS.add(EntityType.GUARDIAN);
        MORPHABLE_MOBS.add(EntityType.ELDER_GUARDIAN);
        MORPHABLE_MOBS.add(EntityType.SILVERFISH);
        MORPHABLE_MOBS.add(EntityType.ENDERMITE);
        MORPHABLE_MOBS.add(EntityType.PHANTOM);
        MORPHABLE_MOBS.add(EntityType.PILLAGER);
        MORPHABLE_MOBS.add(EntityType.VINDICATOR);
        MORPHABLE_MOBS.add(EntityType.EVOKER);
        MORPHABLE_MOBS.add(EntityType.RAVAGER);
        MORPHABLE_MOBS.add(EntityType.VEX);
        MORPHABLE_MOBS.add(EntityType.HOGLIN);
        MORPHABLE_MOBS.add(EntityType.ZOGLIN);
        MORPHABLE_MOBS.add(EntityType.PIGLIN_BRUTE);
        MORPHABLE_MOBS.add(EntityType.WARDEN);
        MORPHABLE_MOBS.add(EntityType.BREEZE);

        // Bosses
        MORPHABLE_MOBS.add(EntityType.ENDER_DRAGON);
        MORPHABLE_MOBS.add(EntityType.WITHER);
        MORPHABLE_MOBS.add(EntityType.ELDER_GUARDIAN);
    }

    public MorphManager(MorphPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean isMorphed(Player player) {
        return morphedPlayers.containsKey(player.getUniqueId());
    }

    public EntityType getMorphType(Player player) {
        return morphedPlayers.get(player.getUniqueId());
    }

    public boolean morphPlayer(Player player, EntityType entityType) {
        // Unmorph first if already morphed
        if (isMorphed(player)) {
            unMorphPlayer(player, false);
        }

        try {
            // Store morph info
            morphedPlayers.put(player.getUniqueId(), entityType);

            // Apply visual disguise by spawning entity and making it invisible passenger trick
            // We use name tag + particle effects to simulate morph visually
            applyMorphEffects(player, entityType);

            plugin.getLogger().info(player.getName() + " morphed into " + entityType.name());
            return true;

        } catch (Exception e) {
            plugin.getLogger().warning("Failed to morph " + player.getName() + ": " + e.getMessage());
            morphedPlayers.remove(player.getUniqueId());
            return false;
        }
    }

    public void unMorphPlayer(Player player, boolean sendMessage) {
        UUID uuid = player.getUniqueId();

        if (!isMorphed(player)) {
            if (sendMessage) {
                player.sendMessage(ChatColor.RED + "អ្នកមិនបានប្រែកាយទេ!");
            }
            return;
        }

        morphedPlayers.remove(uuid);

        // Remove disguise entity if any
        Entity disguise = disguiseEntities.remove(uuid);
        if (disguise != null && !disguise.isDead()) {
            disguise.remove();
        }

        // Reset player display name
        player.setCustomName(null);
        player.setCustomNameVisible(false);

        if (sendMessage) {
            player.sendMessage(ChatColor.GREEN + "✔ អ្នកបានប្រែកាយទៅជារូបរាងធម្មតាវិញ!");
        }
    }

    public void unMorphAll() {
        for (UUID uuid : new HashSet<>(morphedPlayers.keySet())) {
            Player player = Bukkit.getPlayer(uuid);
            if (player != null) {
                unMorphPlayer(player, false);
            }
        }
        morphedPlayers.clear();
        disguiseEntities.clear();
    }

    private void applyMorphEffects(Player player, EntityType entityType) {
        String mobName = formatMobName(entityType);
        player.setCustomName(ChatColor.YELLOW + "[" + mobName + "] " + ChatColor.WHITE + player.getName());
        player.setCustomNameVisible(true);
    }

    public static String formatMobName(EntityType type) {
        String name = type.name().replace("_", " ");
        String[] words = name.toLowerCase().split(" ");
        StringBuilder result = new StringBuilder();
        for (String word : words) {
            result.append(Character.toUpperCase(word.charAt(0)))
                  .append(word.substring(1)).append(" ");
        }
        return result.toString().trim();
    }

    public static EntityType findMobByName(String name) {
        String upper = name.toUpperCase().replace(" ", "_").replace("-", "_");
        for (EntityType type : MORPHABLE_MOBS) {
            if (type.name().equals(upper)) {
                return type;
            }
        }
        // Partial match
        for (EntityType type : MORPHABLE_MOBS) {
            if (type.name().contains(upper)) {
                return type;
            }
        }
        return null;
    }
}
