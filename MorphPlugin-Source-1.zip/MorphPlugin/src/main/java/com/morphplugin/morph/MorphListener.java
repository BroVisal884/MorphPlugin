package com.morphplugin.morph;

import org.bukkit.ChatColor;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityTargetEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class MorphListener implements Listener {

    private final MorphPlugin plugin;
    private final MorphManager morphManager;

    public MorphListener(MorphPlugin plugin) {
        this.plugin = plugin;
        this.morphManager = plugin.getMorphManager();
    }

    // Save morph on disconnect (optional: restore on rejoin)
    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        if (morphManager.isMorphed(player)) {
            morphManager.unMorphPlayer(player, false);
        }
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        if (player.hasPermission("morph.use")) {
            player.sendMessage(ChatColor.GOLD + "[MorphPlugin] " + ChatColor.GREEN
                    + "ស្វាគមន៍! ប្រើ " + ChatColor.YELLOW + "/morph <mob>"
                    + ChatColor.GREEN + " ដើម្បីប្រែកាយ!");
        }
    }

    // If a player is morphed as a hostile mob, prevent mobs from targeting them
    @EventHandler(priority = EventPriority.NORMAL)
    public void onEntityTarget(EntityTargetEvent event) {
        if (event.getTarget() instanceof Player player) {
            if (morphManager.isMorphed(player)) {
                EntityType morphType = morphManager.getMorphType(player);
                // If player is morphed as same type as attacker, don't target
                if (event.getEntity().getType() == morphType) {
                    event.setCancelled(true);
                }
            }
        }
    }

    // Bonus: Show morph info when player takes damage
    @EventHandler
    public void onPlayerDamage(EntityDamageByEntityEvent event) {
        if (event.getEntity() instanceof Player player) {
            if (morphManager.isMorphed(player)) {
                EntityType morphType = morphManager.getMorphType(player);
                // Some mobs like Enderman teleport - just flavor message
            }
        }
    }
}
