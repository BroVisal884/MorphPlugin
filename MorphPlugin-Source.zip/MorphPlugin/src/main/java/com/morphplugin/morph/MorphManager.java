package com.morphplugin.morph;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

import java.util.*;

public class MorphManager {

    private final MorphPlugin plugin;
    private final Map<UUID, EntityType> morphedPlayers = new HashMap<>();

    public static final List<EntityType> MORPHABLE_MOBS = new ArrayList<>();

    static {
        // Passive
        MORPHABLE_MOBS.add(EntityType.COW);
        MORPHABLE_MOBS.add(EntityType.PIG);
        MORPHABLE_MOBS.add(EntityType.SHEEP);
        MORPHABLE_MOBS.add(EntityType.CHICKEN);
        MORPHABLE_MOBS.add(EntityType.HORSE);
        MORPHABLE_MOBS.add(EntityType.DONKEY);
        MORPHABLE_MOBS.add(EntityType.MULE);
        MORPHABLE_MOBS.add(EntityType.RABBIT);
        MORPHABLE_MOBS.add(EntityType.WOLF);
        MORPHABLE_MOBS.add(EntityType.CAT);
        MORPHABLE_MOBS.add(EntityType.OCELOT);
        MORPHABLE_MOBS.add(EntityType.FOX);
        MORPHABLE_MOBS.add(EntityType.PANDA);
        MORPHABLE_MOBS.add(EntityType.POLAR_BEAR);
        MORPHABLE_MOBS.add(EntityType.TURTLE);
        MORPHABLE_MOBS.add(EntityType.PARROT);
        MORPHABLE_MOBS.add(EntityType.BEE);
        MORPHABLE_MOBS.add(EntityType.MOOSHROOM);
        MORPHABLE_MOBS.add(EntityType.LLAMA);
        MORPHABLE_MOBS.add(EntityType.TRADER_LLAMA);
        MORPHABLE_MOBS.add(EntityType.VILLAGER);
        MORPHABLE_MOBS.add(EntityType.WANDERING_TRADER);
        MORPHABLE_MOBS.add(EntityType.IRON_GOLEM);
        MORPHABLE_MOBS.add(EntityType.SNOW_GOLEM);
        MORPHABLE_MOBS.add(EntityType.BAT);
        MORPHABLE_MOBS.add(EntityType.SQUID);
        MORPHABLE_MOBS.add(EntityType.GLOW_SQUID);
        MORPHABLE_MOBS.add(EntityType.COD);
        MORPHABLE_MOBS.add(EntityType.SALMON);
        MORPHABLE_MOBS.add(EntityType.PUFFERFISH);
        MORPHABLE_MOBS.add(EntityType.TROPICAL_FISH);
        MORPHABLE_MOBS.add(EntityType.DOLPHIN);
        MORPHABLE_MOBS.add(EntityType.AXOLOTL);
        MORPHABLE_MOBS.add(EntityType.FROG);
        MORPHABLE_MOBS.add(EntityType.TADPOLE);
        MORPHABLE_MOBS.add(EntityType.ALLAY);
        MORPHABLE_MOBS.add(EntityType.SNIFFER);
        MORPHABLE_MOBS.add(EntityType.CAMEL);
        MORPHABLE_MOBS.add(EntityType.ARMADILLO);
        // Neutral
        MORPHABLE_MOBS.add(EntityType.SPIDER);
        MORPHABLE_MOBS.add(EntityType.CAVE_SPIDER);
        MORPHABLE_MOBS.add(EntityType.ENDERMAN);
        MORPHABLE_MOBS.add(EntityType.PIGLIN);
        MORPHABLE_MOBS.add(EntityType.GOAT);
        // Hostile
        MORPHABLE_MOBS.add(EntityType.ZOMBIE);
        MORPHABLE_MOBS.add(EntityType.ZOMBIE_VILLAGER);
        MORPHABLE_MOBS.add(EntityType.HUSK);
        MORPHABLE_MOBS.add(EntityType.DROWNED);
        MORPHABLE_MOBS.add(EntityType.SKELETON);
        MORPHABLE_MOBS.add(EntityType.STRAY);
        MORPHABLE_MOBS.add(EntityType.WITHER_SKELETON);
        MORPHABLE_MOBS.add(EntityType.CREEPER);
        MORPHABLE_MOBS.add(EntityType.SLIME);
        MORPHABLE_MOBS.add(EntityType.MAGMA_CUBE);
        MORPHABLE_MOBS.add(EntityType.BLAZE);
        MORPHABLE_MOBS.add(EntityType.GHAST);
        MORPHABLE_MOBS.add(EntityType.WITCH);
        MORPHABLE_MOBS.add(EntityType.GUARDIAN);
        MORPHABLE_MOBS.add(EntityType.ELDER_GUARDIAN);
        MORPHABLE_MOBS.add(EntityType.SILVERFISH);
        MORPHABLE_MOBS.add(EntityType.ENDERMITE);
        MORPHABLE_MOBS.add(EntityType.PHANTOM);
        MORPHABLE_MOBS.add(EntityType.PILLAGER);
        MORPHABLE_MOBS.add(EntityType.VINDICATOR);
        MORPHABLE_MOBS.add(EntityType.EVOKER);
        MORPHABLE_MOBS.add(EntityType.RAVAGER);
        MORPHABLE_MOBS.add(EntityType.VEX);
        MORPHABLE_MOBS.add(EntityType.HOGLIN);
        MORPHABLE_MOBS.add(EntityType.ZOGLIN);
        MORPHABLE_MOBS.add(EntityType.PIGLIN_BRUTE);
        MORPHABLE_MOBS.add(EntityType.WARDEN);
        MORPHABLE_MOBS.add(EntityType.BREEZE);
        // Bosses
        MORPHABLE_MOBS.add(EntityType.ENDER_DRAGON);
        MORPHABLE_MOBS.add(EntityType.WITHER);
    }

    public MorphManager(MorphPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean isMorphed(Player player) {
        return morphedPlayers.containsKey(player.getUniqueId());
    }

    public EntityType getMorphType(Player player) {
        return morphedPlayers.get(player.getUniqueId());
    }

    public boolean morphPlayer(Player player, EntityType entityType) {
        if (isMorphed(player)) {
            unMorphPlayer(player, false);
        }

        morphedPlayers.put(player.getUniqueId(), entityType);
        applyMobAbilities(player, entityType);

        player.setCustomName(ChatColor.YELLOW + "[" + formatMobName(entityType) + "] "
                + ChatColor.WHITE + player.getName());
        player.setCustomNameVisible(true);

        plugin.getLogger().info(player.getName() + " morphed into " + entityType.name());
        return true;
    }

    public void unMorphPlayer(Player player, boolean sendMessage) {
        if (!isMorphed(player)) {
            if (sendMessage) player.sendMessage(ChatColor.RED + "អ្នកមិនបានប្រែកាយទេ!");
            return;
        }

        morphedPlayers.remove(player.getUniqueId());
        removeMobAbilities(player);

        player.setCustomName(null);
        player.setCustomNameVisible(false);

        if (sendMessage) {
            player.sendMessage(ChatColor.GREEN + "✔ អ្នកបានប្រែកាយទៅជារូបរាងធម្មតាវិញ!");
        }
    }

    public void unMorphAll() {
        for (UUID uuid : new HashSet<>(morphedPlayers.keySet())) {
            Player player = Bukkit.getPlayer(uuid);
            if (player != null) unMorphPlayer(player, false);
        }
        morphedPlayers.clear();
    }

    public void applyMobAbilities(Player player, EntityType type) {
        removeMobAbilities(player);

        int INF = 999999;

        switch (type) {
            // ===== FLY MOBS =====
            case BEE, PARROT, ALLAY, VEX -> {
                player.setAllowFlight(true);
                player.setFlying(true);
                addEffect(player, PotionEffectType.SPEED, 1, INF);
            }
            case BAT, PHANTOM -> {
                player.setAllowFlight(true);
                player.setFlying(true);
                addEffect(player, PotionEffectType.NIGHT_VISION, 0, INF);
            }
            case BLAZE, GHAST -> {
                player.setAllowFlight(true);
                player.setFlying(true);
                addEffect(player, PotionEffectType.FIRE_RESISTANCE, 0, INF);
            }
            case ENDER_DRAGON -> {
                player.setAllowFlight(true);
                player.setFlying(true);
                addEffect(player, PotionEffectType.RESISTANCE, 3, INF);
                addEffect(player, PotionEffectType.STRENGTH, 2, INF);
                addEffect(player, PotionEffectType.HEALTH_BOOST, 9, INF);
            }
            case WITHER -> {
                player.setAllowFlight(true);
                player.setFlying(true);
                addEffect(player, PotionEffectType.STRENGTH, 2, INF);
                addEffect(player, PotionEffectType.HEALTH_BOOST, 9, INF);
                addEffect(player, PotionEffectType.FIRE_RESISTANCE, 0, INF);
            }
            // ===== WATER MOBS =====
            case SQUID, GLOW_SQUID, COD, SALMON, PUFFERFISH, TROPICAL_FISH, TADPOLE -> {
                addEffect(player, PotionEffectType.WATER_BREATHING, 0, INF);
                addEffect(player, PotionEffectType.DOLPHINS_GRACE, 0, INF);
            }
            case DOLPHIN -> {
                addEffect(player, PotionEffectType.WATER_BREATHING, 0, INF);
                addEffect(player, PotionEffectType.DOLPHINS_GRACE, 1, INF);
                addEffect(player, PotionEffectType.SPEED, 1, INF);
            }
            case DROWNED, AXOLOTL -> {
                addEffect(player, PotionEffectType.WATER_BREATHING, 0, INF);
                addEffect(player, PotionEffectType.DOLPHINS_GRACE, 0, INF);
                addEffect(player, PotionEffectType.NIGHT_VISION, 0, INF);
            }
            case TURTLE -> {
                addEffect(player, PotionEffectType.WATER_BREATHING, 0, INF);
                addEffect(player, PotionEffectType.RESISTANCE, 1, INF);
            }
            // ===== FAST MOBS =====
            case HORSE, DONKEY, MULE -> {
                addEffect(player, PotionEffectType.SPEED, 3, INF);
                addEffect(player, PotionEffectType.JUMP_BOOST, 2, INF);
            }
            case RABBIT, FOX -> {
                addEffect(player, PotionEffectType.SPEED, 2, INF);
                addEffect(player, PotionEffectType.JUMP_BOOST, 3, INF);
            }
            case CAMEL -> {
                addEffect(player, PotionEffectType.SPEED, 1, INF);
                addEffect(player, PotionEffectType.JUMP_BOOST, 1, INF);
            }
            case GOAT -> {
                addEffect(player, PotionEffectType.JUMP_BOOST, 4, INF);
                addEffect(player, PotionEffectType.SPEED, 0, INF);
            }
            // ===== SPIDER (wall climb via listener) =====
            case SPIDER -> {
                addEffect(player, PotionEffectType.SPEED, 1, INF);
                addEffect(player, PotionEffectType.NIGHT_VISION, 0, INF);
            }
            case CAVE_SPIDER -> {
                addEffect(player, PotionEffectType.SPEED, 2, INF);
                addEffect(player, PotionEffectType.NIGHT_VISION, 0, INF);
                addEffect(player, PotionEffectType.POISON, 0, INF);
            }
            // ===== STRONG MOBS =====
            case IRON_GOLEM -> {
                addEffect(player, PotionEffectType.STRENGTH, 3, INF);
                addEffect(player, PotionEffectType.RESISTANCE, 3, INF);
                addEffect(player, PotionEffectType.HEALTH_BOOST, 9, INF);
                addEffect(player, PotionEffectType.SLOWNESS, 1, INF);
            }
            case RAVAGER -> {
                addEffect(player, PotionEffectType.STRENGTH, 2, INF);
                addEffect(player, PotionEffectType.RESISTANCE, 2, INF);
                addEffect(player, PotionEffectType.HEALTH_BOOST, 4, INF);
            }
            case WARDEN -> {
                addEffect(player, PotionEffectType.STRENGTH, 4, INF);
                addEffect(player, PotionEffectType.RESISTANCE, 4, INF);
                addEffect(player, PotionEffectType.HEALTH_BOOST, 9, INF);
                addEffect(player, PotionEffectType.DARKNESS, 0, INF);
            }
            case POLAR_BEAR, PANDA -> {
                addEffect(player, PotionEffectType.STRENGTH, 1, INF);
                addEffect(player, PotionEffectType.RESISTANCE, 1, INF);
                addEffect(player, PotionEffectType.HEALTH_BOOST, 2, INF);
            }
            case SNIFFER -> {
                addEffect(player, PotionEffectType.HEALTH_BOOST, 4, INF);
                addEffect(player, PotionEffectType.RESISTANCE, 1, INF);
            }
            // ===== FIRE MOBS =====
            case MAGMA_CUBE, HOGLIN, ZOGLIN, PIGLIN, PIGLIN_BRUTE -> {
                addEffect(player, PotionEffectType.FIRE_RESISTANCE, 0, INF);
                addEffect(player, PotionEffectType.STRENGTH, 1, INF);
            }
            // ===== NIGHT VISION MOBS =====
            case ENDERMAN -> {
                addEffect(player, PotionEffectType.NIGHT_VISION, 0, INF);
                addEffect(player, PotionEffectType.SPEED, 1, INF);
            }
            case CAT, OCELOT -> {
                addEffect(player, PotionEffectType.NIGHT_VISION, 0, INF);
                addEffect(player, PotionEffectType.SPEED, 1, INF);
                addEffect(player, PotionEffectType.JUMP_BOOST, 1, INF);
            }
            // ===== UNDEAD MOBS =====
            case ZOMBIE, ZOMBIE_VILLAGER, HUSK -> {
                addEffect(player, PotionEffectType.STRENGTH, 0, INF);
            }
            case SKELETON, STRAY -> {
                addEffect(player, PotionEffectType.SPEED, 1, INF);
            }
            case WITHER_SKELETON -> {
                addEffect(player, PotionEffectType.FIRE_RESISTANCE, 0, INF);
                addEffect(player, PotionEffectType.STRENGTH, 1, INF);
            }
            // ===== SPECIAL MOBS =====
            case WITCH -> {
                addEffect(player, PotionEffectType.SPEED, 1, INF);
                addEffect(player, PotionEffectType.WATER_BREATHING, 0, INF);
                addEffect(player, PotionEffectType.FIRE_RESISTANCE, 0, INF);
            }
            case CREEPER -> {
                addEffect(player, PotionEffectType.SPEED, 1, INF);
            }
            case GUARDIAN -> {
                addEffect(player, PotionEffectType.WATER_BREATHING, 0, INF);
            }
            case ELDER_GUARDIAN -> {
                addEffect(player, PotionEffectType.WATER_BREATHING, 0, INF);
                addEffect(player, PotionEffectType.MINING_FATIGUE, 2, INF);
            }
            case WOLF -> {
                addEffect(player, PotionEffectType.SPEED, 1, INF);
                addEffect(player, PotionEffectType.STRENGTH, 0, INF);
            }
            case SNOW_GOLEM -> {
                addEffect(player, PotionEffectType.SPEED, 0, INF);
            }
            default -> { /* No special abilities */ }
        }
    }

    private void removeMobAbilities(Player player) {
        for (PotionEffect effect : player.getActivePotionEffects()) {
            player.removePotionEffect(effect.getType());
        }
        if (!player.getGameMode().name().equals("CREATIVE") &&
            !player.getGameMode().name().equals("SPECTATOR")) {
            player.setAllowFlight(false);
            player.setFlying(false);
        }
    }

    private void addEffect(Player player, PotionEffectType type, int amplifier, int duration) {
        player.addPotionEffect(new PotionEffect(type, duration, amplifier, false, false, true));
    }

    public static String formatMobName(EntityType type) {
        String name = type.name().replace("_", " ");
        String[] words = name.toLowerCase().split(" ");
        StringBuilder result = new StringBuilder();
        for (String word : words) {
            result.append(Character.toUpperCase(word.charAt(0)))
                  .append(word.substring(1)).append(" ");
        }
        return result.toString().trim();
    }

    public static EntityType findMobByName(String name) {
        String upper = name.toUpperCase().replace(" ", "_").replace("-", "_");
        for (EntityType type : MORPHABLE_MOBS) {
            if (type.name().equals(upper)) return type;
        }
        for (EntityType type : MORPHABLE_MOBS) {
            if (type.name().contains(upper)) return type;
        }
        return null;
    }
}
