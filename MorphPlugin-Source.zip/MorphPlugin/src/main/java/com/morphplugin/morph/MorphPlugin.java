package com.morphplugin.morph;

import org.bukkit.plugin.java.JavaPlugin;

public class MorphPlugin extends JavaPlugin {

    private static MorphPlugin instance;
    private MorphManager morphManager;

    @Override
    public void onEnable() {
        instance = this;
        this.morphManager = new MorphManager(this);

        // Register commands
        MorphCommand morphCommand = new MorphCommand(this);
        getCommand("morph").setExecutor(morphCommand);
        getCommand("morph").setTabCompleter(morphCommand);
        getCommand("unmorph").setExecutor(morphCommand);

        // Register listeners
        getServer().getPluginManager().registerEvents(new MorphListener(this), this);

        getLogger().info("=================================");
        getLogger().info("  MorphPlugin enabled! v" + getDescription().getVersion());
        getLogger().info("  Transform into any mob!");
        getLogger().info("=================================");
    }

    @Override
    public void onDisable() {
        if (morphManager != null) {
            morphManager.unMorphAll();
        }
        getLogger().info("MorphPlugin disabled! All players unmorphed.");
    }

    public static MorphPlugin getInstance() {
        return instance;
    }

    public MorphManager getMorphManager() {
        return morphManager;
    }
}
