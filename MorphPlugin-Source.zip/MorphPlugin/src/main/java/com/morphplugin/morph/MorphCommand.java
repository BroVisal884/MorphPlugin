package com.morphplugin.morph;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public class MorphCommand implements CommandExecutor, TabCompleter {

    private final MorphPlugin plugin;
    private final MorphManager morphManager;

    private static final int MOBS_PER_PAGE = 10;

    public MorphCommand(MorphPlugin plugin) {
        this.plugin = plugin;
        this.morphManager = plugin.getMorphManager();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        // /unmorph command
        if (command.getName().equalsIgnoreCase("unmorph")) {
            if (!(sender instanceof Player player)) {
                sender.sendMessage(ChatColor.RED + "Only players can use this command!");
                return true;
            }
            morphManager.unMorphPlayer(player, true);
            return true;
        }

        // /morph command
        if (!(sender instanceof Player player)) {
            sender.sendMessage(ChatColor.RED + "Only players can use this command!");
            return true;
        }

        if (!player.hasPermission("morph.use")) {
            player.sendMessage(ChatColor.RED + "អ្នកគ្មានសិទ្ធិប្រើ command នេះ!");
            return true;
        }

        if (args.length == 0) {
            sendHelp(player);
            return true;
        }

        String subCmd = args[0].toLowerCase();

        switch (subCmd) {
            case "list" -> {
                int page = 1;
                if (args.length > 1) {
                    try {
                        page = Integer.parseInt(args[1]);
                    } catch (NumberFormatException ignored) {}
                }
                sendMobList(player, page);
            }
            case "off", "remove", "none" -> {
                morphManager.unMorphPlayer(player, true);
            }
            case "help" -> sendHelp(player);
            default -> {
                // Try to morph into the mob
                EntityType entityType = MorphManager.findMobByName(args[0]);
                if (entityType == null) {
                    player.sendMessage(ChatColor.RED + "❌ មិនរកឃើញ mob ឈ្មោះ: " + ChatColor.YELLOW + args[0]);
                    player.sendMessage(ChatColor.GRAY + "ប្រើ " + ChatColor.WHITE + "/morph list " + ChatColor.GRAY + "ដើម្បីមើលបញ្ជី mob ទាំងអស់");
                    return true;
                }

                boolean success = morphManager.morphPlayer(player, entityType);
                if (success) {
                    player.sendMessage(ChatColor.GREEN + "✔ អ្នកបានប្រែកាយទៅជា "
                            + ChatColor.YELLOW + MorphManager.formatMobName(entityType) + ChatColor.GREEN + "!");
                    player.sendMessage(ChatColor.GRAY + "ប្រើ " + ChatColor.WHITE + "/unmorph " + ChatColor.GRAY + "ដើម្បីប្រែកាយត្រឡប់មក");
                } else {
                    player.sendMessage(ChatColor.RED + "❌ ប្រែកាយមិនបាន! សូមព្យាយាមម្តងទៀត");
                }
            }
        }
        return true;
    }

    private void sendHelp(Player player) {
        player.sendMessage(ChatColor.GOLD + "══════════════════════════════");
        player.sendMessage(ChatColor.YELLOW + "       🐾 MorphPlugin Help 🐾");
        player.sendMessage(ChatColor.GOLD + "══════════════════════════════");
        player.sendMessage(ChatColor.AQUA + "/morph <mob>" + ChatColor.WHITE + " - ប្រែកាយទៅជា mob");
        player.sendMessage(ChatColor.AQUA + "/morph list [page]" + ChatColor.WHITE + " - មើលបញ្ជី mob ទាំងអស់");
        player.sendMessage(ChatColor.AQUA + "/morph off" + ChatColor.WHITE + " - ប្រែកាយទៅជារូបរាងធម្មតា");
        player.sendMessage(ChatColor.AQUA + "/unmorph" + ChatColor.WHITE + " - ប្រែកាយទៅជារូបរាងធម្មតា");
        player.sendMessage(ChatColor.GOLD + "══════════════════════════════");

        if (morphManager.isMorphed(player)) {
            EntityType current = morphManager.getMorphType(player);
            player.sendMessage(ChatColor.GREEN + "រូបរាងបច្ចុប្បន្ន: " + ChatColor.YELLOW + MorphManager.formatMobName(current));
        }
    }

    private void sendMobList(Player player, int page) {
        List<EntityType> mobs = MorphManager.MORPHABLE_MOBS;
        int totalPages = (int) Math.ceil((double) mobs.size() / MOBS_PER_PAGE);
        page = Math.max(1, Math.min(page, totalPages));

        int start = (page - 1) * MOBS_PER_PAGE;
        int end = Math.min(start + MOBS_PER_PAGE, mobs.size());

        player.sendMessage(ChatColor.GOLD + "══════════════════════════════");
        player.sendMessage(ChatColor.YELLOW + "   🐾 Mob List (Page " + page + "/" + totalPages + ") 🐾");
        player.sendMessage(ChatColor.GOLD + "══════════════════════════════");

        for (int i = start; i < end; i++) {
            EntityType type = mobs.get(i);
            String name = MorphManager.formatMobName(type);
            player.sendMessage(ChatColor.AQUA + "• " + ChatColor.WHITE + name
                    + ChatColor.GRAY + " (/morph " + type.name().toLowerCase() + ")");
        }

        player.sendMessage(ChatColor.GOLD + "══════════════════════════════");
        if (page < totalPages) {
            player.sendMessage(ChatColor.GRAY + "ទំព័របន្ទាប់: " + ChatColor.WHITE + "/morph list " + (page + 1));
        }
        player.sendMessage(ChatColor.GRAY + "សរុប: " + ChatColor.WHITE + mobs.size() + " mobs");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> completions = new ArrayList<>();

        if (command.getName().equalsIgnoreCase("morph")) {
            if (args.length == 1) {
                completions.add("list");
                completions.add("off");
                completions.add("help");
                for (EntityType type : MorphManager.MORPHABLE_MOBS) {
                    String name = type.name().toLowerCase();
                    if (name.startsWith(args[0].toLowerCase())) {
                        completions.add(name);
                    }
                }
            } else if (args.length == 2 && args[0].equalsIgnoreCase("list")) {
                completions.add("1");
                completions.add("2");
                completions.add("3");
            }
        }

        return completions;
    }
}
