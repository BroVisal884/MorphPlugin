package com.morphplugin.morph;

import org.bukkit.ChatColor;
import org.bukkit.GameMode;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityTargetEvent;
import org.bukkit.event.player.PlayerGameModeChangeEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerMoveEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerToggleFlightEvent;

public class MorphListener implements Listener {

    private final MorphPlugin plugin;
    private final MorphManager morphManager;

    public MorphListener(MorphPlugin plugin) {
        this.plugin = plugin;
        this.morphManager = plugin.getMorphManager();
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        if (player.hasPermission("morph.use")) {
            player.sendMessage(ChatColor.GOLD + "[MorphPlugin] " + ChatColor.GREEN
                    + "ស្វាគមន៍! ប្រើ " + ChatColor.YELLOW + "/morph <mob>"
                    + ChatColor.GREEN + " ដើម្បីប្រែកាយ!");
        }
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        if (morphManager.isMorphed(player)) {
            morphManager.unMorphPlayer(player, false);
        }
    }

    // =============================================
    // រក្សា flight ពេល player land (ដើម្បីឱ្យហោះទ្រាន់)
    // =============================================
    @EventHandler(priority = EventPriority.HIGH)
    public void onPlayerToggleFlight(PlayerToggleFlightEvent event) {
        Player player = event.getPlayer();
        if (!morphManager.isMorphed(player)) return;

        EntityType morphType = morphManager.getMorphType(player);

        // ប្រភេទ mob ដែលអាចហោះ
        if (isFlyingMob(morphType)) {
            if (!event.isFlying()) {
                // ពេល player ព្យាយាម land — ឱ្យហោះបន្ត
                plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                    if (player.isOnline() && morphManager.isMorphed(player)) {
                        player.setAllowFlight(true);
                    }
                }, 1L);
            }
        }
    }

    // =============================================
    // Spider wall climbing
    // =============================================
    @EventHandler
    public void onPlayerMove(PlayerMoveEvent event) {
        Player player = event.getPlayer();
        if (!morphManager.isMorphed(player)) return;

        EntityType morphType = morphManager.getMorphType(player);

        // Spider ចេះឡើងជញ្ជាំង
        if (morphType == EntityType.SPIDER || morphType == EntityType.CAVE_SPIDER) {
            Block blockNorth = player.getLocation().getBlock().getRelative(BlockFace.NORTH);
            Block blockSouth = player.getLocation().getBlock().getRelative(BlockFace.SOUTH);
            Block blockEast = player.getLocation().getBlock().getRelative(BlockFace.EAST);
            Block blockWest = player.getLocation().getBlock().getRelative(BlockFace.WEST);

            boolean adjacentToWall = (!blockNorth.getType().isAir() ||
                                      !blockSouth.getType().isAir() ||
                                      !blockEast.getType().isAir() ||
                                      !blockWest.getType().isAir());

            if (adjacentToWall) {
                player.setAllowFlight(true);
                // ឱ្យ player ឡើង
                if (player.isSneaking()) {
                    player.setFlying(false);
                } else {
                    player.setVelocity(player.getVelocity().setY(0.2));
                }
            } else {
                if (player.getGameMode() != GameMode.CREATIVE &&
                    player.getGameMode() != GameMode.SPECTATOR) {
                    player.setAllowFlight(false);
                }
            }
        }
    }

    // =============================================
    // ពេល game mode ផ្លាស់ប្ដូរ — reapply abilities
    // =============================================
    @EventHandler
    public void onGameModeChange(PlayerGameModeChangeEvent event) {
        Player player = event.getPlayer();
        if (morphManager.isMorphed(player)) {
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                if (player.isOnline() && morphManager.isMorphed(player)) {
                    EntityType type = morphManager.getMorphType(player);
                    morphManager.applyMobAbilities(player, type);
                }
            }, 2L);
        }
    }

    // =============================================
    // Mob ប្រភេទដូចគ្នា មិន target player
    // =============================================
    @EventHandler(priority = EventPriority.NORMAL)
    public void onEntityTarget(EntityTargetEvent event) {
        if (event.getTarget() instanceof Player player) {
            if (morphManager.isMorphed(player)) {
                EntityType morphType = morphManager.getMorphType(player);
                if (event.getEntity().getType() == morphType) {
                    event.setCancelled(true);
                }
            }
        }
    }

    // =============================================
    // Helper
    // =============================================
    private boolean isFlyingMob(EntityType type) {
        return switch (type) {
            case BEE, PARROT, ALLAY, VEX, BAT, PHANTOM,
                 BLAZE, GHAST, ENDER_DRAGON, WITHER -> true;
            default -> false;
        };
    }
}
