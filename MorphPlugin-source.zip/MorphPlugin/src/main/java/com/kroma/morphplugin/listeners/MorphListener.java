package com.kroma.morphplugin.listeners;

import com.kroma.morphplugin.MorphPlugin;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.player.PlayerQuitEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.entity.PlayerDeathEvent;

/**
 * MorphListener — Handles events related to morphed players.
 */
public class MorphListener implements Listener {

    private final MorphPlugin plugin;

    public MorphListener(MorphPlugin plugin) {
        this.plugin = plugin;
    }

    /**
     * Unmorph player on quit (unless persist-on-relog is true).
     */
    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        boolean persist = plugin.getConfig().getBoolean("settings.persist-on-relog", false);

        if (!persist && plugin.getMorphManager().isMorphed(player.getUniqueId())) {
            plugin.getMorphManager().unmorphPlayer(player);
        }
    }

    /**
     * Remind morphed player of their status on join.
     */
    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        if (plugin.getMorphManager().isMorphed(player.getUniqueId())) {
            var mobType = plugin.getMorphManager().getMorphType(player.getUniqueId());
            player.sendMessage("§6[MorphPlugin] §eYou are still morphed as: §f"
                    + plugin.getMorphManager().formatMobName(mobType));
        }
    }

    /**
     * Block morphing in combat if config disallows it.
     */
    @EventHandler
    public void onEntityDamage(EntityDamageByEntityEvent event) {
        // If a morphed player attacks, check config
        if (event.getDamager() instanceof Player attacker) {
            if (plugin.getMorphManager().isMorphed(attacker.getUniqueId())) {
                boolean allowInCombat = plugin.getConfig()
                        .getBoolean("settings.allow-morph-in-combat", false);
                if (!allowInCombat) {
                    // Mark them as in combat (simple — just send a tip)
                    attacker.sendActionBar("§c⚔ You are in combat — morphing is locked!");
                }
            }
        }
    }

    /**
     * Unmorph player on death.
     */
    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        if (plugin.getMorphManager().isMorphed(player.getUniqueId())) {
            plugin.getMorphManager().unmorphPlayer(player);
            player.sendMessage("§c💀 You died and have been unmorphed.");
        }
    }
}
