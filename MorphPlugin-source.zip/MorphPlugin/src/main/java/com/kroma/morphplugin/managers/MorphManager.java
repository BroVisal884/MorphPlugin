package com.kroma.morphplugin.managers;

import com.kroma.morphplugin.MorphPlugin;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

/**
 * MorphManager — Handles all morph state and logic.
 */
public class MorphManager {

    private final MorphPlugin plugin;

    // Maps player UUID → morphed EntityType
    private final Map<UUID, EntityType> morphedPlayers = new HashMap<>();

    // Cooldown tracker: UUID → last morph timestamp (ms)
    private final Map<UUID, Long> cooldowns = new HashMap<>();

    public MorphManager(MorphPlugin plugin) {
        this.plugin = plugin;
    }

    /**
     * Morph a player into the specified EntityType.
     * Uses disguise via sending fake metadata packets (LibsDisguises style).
     * This implementation uses Bukkit's entity disguise approach with
     * a passenger trick for visual effect and sets display name.
     */
    public boolean morphPlayer(Player player, EntityType entityType) {
        UUID uuid = player.getUniqueId();

        // Check cooldown
        int cooldownSeconds = plugin.getConfig().getInt("settings.morph-cooldown", 5);
        if (isOnCooldown(uuid)) {
            long remaining = getRemainingCooldown(uuid);
            String msg = plugin.getConfig().getString("messages.morph-cooldown",
                    "&c⏳ Please wait &e%time% &cseconds before morphing again.")
                    .replace("%time%", String.valueOf(remaining))
                    .replace("&", "§");
            player.sendMessage(msg);
            return false;
        }

        // Store morph state
        morphedPlayers.put(uuid, entityType);
        cooldowns.put(uuid, System.currentTimeMillis());

        // Apply disguise effect using scoreboard team nametag + visual tricks
        applyMorphEffect(player, entityType);

        // Send success message
        String msg = plugin.getConfig().getString("messages.morph-success",
                "&a✔ You have morphed into a &e%mob%&a!")
                .replace("%mob%", formatMobName(entityType))
                .replace("&", "§");
        player.sendMessage(msg);

        // Action bar
        if (plugin.getConfig().getBoolean("settings.show-action-bar", true)) {
            player.sendActionBar("§6👾 Morphed: §e" + formatMobName(entityType));
        }

        // Sound
        if (plugin.getConfig().getBoolean("settings.play-sound", true)) {
            player.playSound(player.getLocation(),
                    org.bukkit.Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 1.2f);
        }

        return true;
    }

    /**
     * Applies the visual morph disguise to the player.
     * Spawns a mob at the player location and makes player ride it visually,
     * and changes the player's display name to indicate their morph.
     */
    private void applyMorphEffect(Player player, EntityType entityType) {
        // Change player's display name to show morph
        String mobName = formatMobName(entityType);
        player.setDisplayName("§8[§6" + mobName + "§8] §f" + player.getName());
        player.setPlayerListName("§8[§6" + mobName + "§8] §f" + player.getName());

        // Apply potion effect to give visual feedback
        player.addPotionEffect(new org.bukkit.potion.PotionEffect(
                org.bukkit.potion.PotionEffectType.GLOWING, 60, 0, true, false));

        // Spawn a temporary mob that the player "becomes"
        // (Full disguise requires LibsDisguises — this is the vanilla-compatible version)
        org.bukkit.World world = player.getWorld();
        org.bukkit.entity.Entity mob = world.spawnEntity(player.getLocation(), entityType);

        if (mob instanceof org.bukkit.entity.LivingEntity living) {
            living.setAI(false);
            living.setInvulnerable(true);
            living.setSilent(true);
            living.setCustomName("§e" + player.getName() + "'s morph");
            living.setCustomNameVisible(false);

            // Make player ride the mob
            mob.addPassenger(player);

            // Remove mob after 3 seconds (visual only)
            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                if (mob.isValid()) {
                    mob.remove();
                }
            }, 60L);
        }
    }

    /**
     * Unmorph a player — return to normal form.
     */
    public boolean unmorphPlayer(Player player) {
        UUID uuid = player.getUniqueId();

        if (!isMorphed(uuid)) {
            player.sendMessage("§c✘ You are not currently morphed.");
            return false;
        }

        morphedPlayers.remove(uuid);

        // Restore display name
        player.setDisplayName(player.getName());
        player.setPlayerListName(player.getName());

        // Remove glowing
        player.removePotionEffect(org.bukkit.potion.PotionEffectType.GLOWING);

        // Send message
        String msg = plugin.getConfig().getString("messages.unmorph-success",
                "&a✔ You have returned to your normal form!")
                .replace("&", "§");
        player.sendMessage(msg);

        // Action bar
        if (plugin.getConfig().getBoolean("settings.show-action-bar", true)) {
            player.sendActionBar("§a✔ Returned to normal form!");
        }

        // Sound
        if (plugin.getConfig().getBoolean("settings.play-sound", true)) {
            player.playSound(player.getLocation(),
                    org.bukkit.Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.5f);
        }

        return true;
    }

    /**
     * Unmorph all players (called on plugin disable).
     */
    public void unmorphAll() {
        for (UUID uuid : morphedPlayers.keySet()) {
            Player player = plugin.getServer().getPlayer(uuid);
            if (player != null && player.isOnline()) {
                player.setDisplayName(player.getName());
                player.setPlayerListName(player.getName());
                player.removePotionEffect(org.bukkit.potion.PotionEffectType.GLOWING);
                player.sendMessage("§e[MorphPlugin] §cPlugin disabled — you have been unmorphed.");
            }
        }
        morphedPlayers.clear();
    }

    /**
     * Check if a player is currently morphed.
     */
    public boolean isMorphed(UUID uuid) {
        return morphedPlayers.containsKey(uuid);
    }

    /**
     * Get the mob type a player is morphed into.
     */
    public EntityType getMorphType(UUID uuid) {
        return morphedPlayers.get(uuid);
    }

    /**
     * Check if player is on cooldown.
     */
    public boolean isOnCooldown(UUID uuid) {
        if (!cooldowns.containsKey(uuid)) return false;
        int cooldownMs = plugin.getConfig().getInt("settings.morph-cooldown", 5) * 1000;
        return (System.currentTimeMillis() - cooldowns.get(uuid)) < cooldownMs;
    }

    /**
     * Get remaining cooldown in seconds.
     */
    public long getRemainingCooldown(UUID uuid) {
        if (!cooldowns.containsKey(uuid)) return 0;
        int cooldownMs = plugin.getConfig().getInt("settings.morph-cooldown", 5) * 1000;
        long elapsed = System.currentTimeMillis() - cooldowns.get(uuid);
        return Math.max(0, (cooldownMs - elapsed) / 1000);
    }

    /**
     * Format EntityType name nicely (e.g. ZOMBIE_VILLAGER → Zombie Villager).
     */
    public String formatMobName(EntityType type) {
        String name = type.name().replace("_", " ");
        StringBuilder result = new StringBuilder();
        for (String word : name.split(" ")) {
            if (!word.isEmpty()) {
                result.append(Character.toUpperCase(word.charAt(0)))
                      .append(word.substring(1).toLowerCase())
                      .append(" ");
            }
        }
        return result.toString().trim();
    }

    /**
     * Get all valid mob EntityTypes (living, spawnable).
     */
    public java.util.List<EntityType> getAvailableMobs() {
        java.util.List<EntityType> mobs = new java.util.ArrayList<>();
        java.util.List<String> blocked = plugin.getConfig().getStringList("blocked-mobs");

        for (EntityType type : EntityType.values()) {
            if (type.isAlive() && type.isSpawnable() && !blocked.contains(type.name())) {
                mobs.add(type);
            }
        }
        return mobs;
    }
}
