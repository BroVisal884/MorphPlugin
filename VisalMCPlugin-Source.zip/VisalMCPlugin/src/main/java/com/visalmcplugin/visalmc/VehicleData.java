package com.visalmcplugin.visalmc;

import org.bukkit.entity.Entity;

import java.util.UUID;

public class VehicleData {

    private final UUID ownerUUID;
    private final VehicleType type;
    private final Entity entity;
    private int fuel;
    private boolean engineOn;

    public VehicleData(UUID ownerUUID, VehicleType type, Entity entity) {
        this.ownerUUID = ownerUUID;
        this.type = type;
        this.entity = entity;
        this.fuel = type.getMaxFuel();
        this.engineOn = true;
    }

    public UUID getOwnerUUID() { return ownerUUID; }
    public VehicleType getType() { return type; }
    public Entity getEntity() { return entity; }
    public int getFuel() { return fuel; }
    public int getMaxFuel() { return type.getMaxFuel(); }
    public boolean isEngineOn() { return engineOn; }

    public void setFuel(int fuel) {
        this.fuel = Math.max(0, Math.min(fuel, type.getMaxFuel()));
    }

    public void addFuel(int amount) {
        setFuel(this.fuel + amount);
    }

    public void consumeFuel(int amount) {
        setFuel(this.fuel - amount);
    }

    public boolean isEmpty() {
        return fuel <= 0;
    }

    public void setEngineOn(boolean on) {
        this.engineOn = on;
    }

    // ភាគរយ fuel សម្រាប់បង្ហាញ
    public int getFuelPercent() {
        return (int) ((double) fuel / type.getMaxFuel() * 100);
    }

    // បង្ហាញ fuel bar
    public String getFuelBar() {
        int bars = getFuelPercent() / 10;
        StringBuilder bar = new StringBuilder("§a");
        for (int i = 0; i < 10; i++) {
            if (i == 5) bar.append("§r");
            if (i < bars) {
                bar.append(i < 3 ? "§c█" : i < 6 ? "§e█" : "§a█");
            } else {
                bar.append("§8█");
            }
        }
        return bar.toString();
    }
}
