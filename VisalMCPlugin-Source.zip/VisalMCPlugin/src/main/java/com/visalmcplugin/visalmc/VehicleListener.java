package com.visalmcplugin.visalmc;

import org.bukkit.ChatColor;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Minecart;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.visalmc.VehicleDestroyEvent;
import org.bukkit.event.visalmc.VehicleEnterEvent;
import org.bukkit.event.visalmc.VehicleExitEvent;

public class VehicleListener implements Listener {

    private final VisalMCPlugin plugin;
    private final VehicleManager vehicleManager;

    public VehicleListener(VisalMCPlugin plugin) {
        this.plugin = plugin;
        this.vehicleManager = plugin.getVehicleManager();
    }

    // ពេល player ចូលជិះ vehicle
    @EventHandler
    public void onVehicleEnter(VehicleEnterEvent event) {
        if (!(event.getEntered() instanceof Player player)) return;
        Entity vehicle = event.getVehicle();

        if (!vehicleManager.isVehicle(vehicle)) return;

        VehicleData data = vehicleManager.getVehicleByEntity(vehicle);
        if (data == null) return;

        // Check fuel
        if (data.isEmpty()) {
            player.sendMessage(ChatColor.RED + "❌ ⛽ Fuel អស់! ចាក់ fuel ជាមុន!");
            event.setCancelled(true);
            return;
        }

        player.sendMessage(ChatColor.GREEN + "✔ ចូលជិះ " + data.getType().getDisplayName() + ChatColor.GREEN + " !");
        player.sendActionBar(net.kyori.adventure.text.Component.text(
            "⛽ " + data.getFuelBar() + " §7" + data.getFuel() + "/" + data.getMaxFuel()
        ));
    }

    // ពេល player ចេញពី vehicle
    @EventHandler
    public void onVehicleExit(VehicleExitEvent event) {
        if (!(event.getExited() instanceof Player player)) return;
        Entity vehicle = event.getVehicle();

        if (!vehicleManager.isVehicle(vehicle)) return;

        VehicleData data = vehicleManager.getVehicleByEntity(vehicle);
        if (data == null) return;

        if (!data.isEmpty()) {
            player.sendMessage(ChatColor.YELLOW + "⚠ អ្នកបានចាកចេញពី "
                    + data.getType().getDisplayName()
                    + ChatColor.GRAY + " (⛽ " + data.getFuel() + "/" + data.getMaxFuel() + ")");
        }
    }

    // ពេល vehicle ត្រូវបំផ្លាញ — ការពារ
    @EventHandler
    public void onVehicleDestroy(VehicleDestroyEvent event) {
        Entity vehicle = event.getVehicle();
        if (!vehicleManager.isVehicle(vehicle)) return;

        VehicleData data = vehicleManager.getVehicleByEntity(vehicle);
        if (data == null) return;

        // អនុញ្ញាតឱ្យ owner destroy vehicle
        if (event.getAttacker() instanceof Player attacker) {
            if (attacker.getUniqueId().equals(data.getOwnerUUID())) {
                Player owner = attacker;
                vehicleManager.removeVehicle(owner, false);
                owner.sendMessage(ChatColor.RED + "🚫 " + data.getType().getDisplayName()
                        + ChatColor.RED + " ត្រូវបានបំផ្លាញ!");
                return;
            }
        }

        // ការពារ vehicle ពី player ផ្សេង
        event.setCancelled(true);
    }

    // ការពារ vehicle ពី damage
    @EventHandler
    public void onEntityDamage(EntityDamageEvent event) {
        Entity entity = event.getEntity();
        if (vehicleManager.isVehicle(entity)) {
            // Allow only explosion and void damage
            if (event.getCause() == EntityDamageEvent.DamageCause.ENTITY_ATTACK) {
                event.setCancelled(true);
            }
        }
    }
}
