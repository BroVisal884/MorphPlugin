package com.visalmcplugin.visalmc;

import org.bukkit.entity.Entity;
import java.util.UUID;

public class VisalMCData {

    private final UUID ownerUUID;
    private final VisalMCType type;
    private final Entity entity;
    private int fuel;

    public VisalMCData(UUID ownerUUID, VisalMCType type, Entity entity) {
        this.ownerUUID = ownerUUID;
        this.type = type;
        this.entity = entity;
        this.fuel = type.getMaxFuel();
    }

    public UUID getOwnerUUID() { return ownerUUID; }
    public VisalMCType getType() { return type; }
    public Entity getEntity() { return entity; }
    public int getFuel() { return fuel; }
    public int getMaxFuel() { return type.getMaxFuel(); }
    public boolean isEmpty() { return fuel <= 0; }

    public void addFuel(int amount) {
        fuel = Math.min(fuel + amount, type.getMaxFuel());
    }

    public void consumeFuel(int amount) {
        fuel = Math.max(fuel - amount, 0);
    }

    public int getFuelPercent() {
        return (int) ((double) fuel / type.getMaxFuel() * 100);
    }

    public String getFuelBar() {
        int bars = getFuelPercent() / 10;
        StringBuilder bar = new StringBuilder();
        for (int i = 0; i < 10; i++) {
            if (i < bars) {
                bar.append(i < 3 ? "§c█" : i < 6 ? "§e█" : "§a█");
            } else {
                bar.append("§8█");
            }
        }
        return bar.toString();
    }
}
