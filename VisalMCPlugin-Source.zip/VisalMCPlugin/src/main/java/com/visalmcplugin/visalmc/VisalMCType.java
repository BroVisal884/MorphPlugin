package com.visalmcplugin.visalmc;

import org.bukkit.Material;
import org.bukkit.entity.EntityType;

public enum VisalMCType {

    CAR(
        "🚗 ឡាន",
        EntityType.MINECART,       // base entity
        Material.IRON_BLOCK,       // fuel item
        100,                       // max fuel
        0.5,                       // speed multiplier
        3,                         // max passengers
        "ឡាន — រត់លឿន, ជិះបាន 3នាក់"
    ),

    MOTORCYCLE(
        "🏍️ ម៉ូតូ",
        EntityType.MINECART,
        Material.COAL,
        60,
        0.7,
        1,
        "ម៉ូតូ — លឿនបំផុត, ជិះបាន 1នាក់"
    ),

    BICYCLE(
        "🚲 កង់",
        EntityType.MINECART,
        Material.WHEAT,
        30,
        0.3,
        1,
        "កង់ — យឺត, ប្រើអាហារជា fuel"
    );

    private final String displayName;
    private final EntityType entityType;
    private final Material fuelItem;
    private final int maxFuel;
    private final double speedMultiplier;
    private final int maxPassengers;
    private final String description;

    VisalMCType(String displayName, EntityType entityType, Material fuelItem,
                int maxFuel, double speedMultiplier, int maxPassengers, String description) {
        this.displayName = displayName;
        this.entityType = entityType;
        this.fuelItem = fuelItem;
        this.maxFuel = maxFuel;
        this.speedMultiplier = speedMultiplier;
        this.maxPassengers = maxPassengers;
        this.description = description;
    }

    public String getDisplayName() { return displayName; }
    public EntityType getEntityType() { return entityType; }
    public Material getFuelItem() { return fuelItem; }
    public int getMaxFuel() { return maxFuel; }
    public double getSpeedMultiplier() { return speedMultiplier; }
    public int getMaxPassengers() { return maxPassengers; }
    public String getDescription() { return description; }

    public static VisalMCType fromString(String name) {
        return switch (name.toLowerCase()) {
            case "car", "ឡាន" -> CAR;
            case "motorcycle", "moto", "ម៉ូតូ" -> MOTORCYCLE;
            case "bicycle", "bike", "កង់" -> BICYCLE;
            default -> null;
        };
    }
}
