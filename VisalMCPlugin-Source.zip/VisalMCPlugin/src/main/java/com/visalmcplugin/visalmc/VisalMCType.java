package com.visalmcplugin.visalmc;

import org.bukkit.Material;
import org.bukkit.entity.EntityType;

public enum VisalMCType {

    CAR("🚗 ឡាន", EntityType.MINECART, Material.IRON_BLOCK, 100, 0.5, 3),
    MOTORCYCLE("🏍️ ម៉ូតូ", EntityType.MINECART, Material.COAL, 60, 0.7, 1),
    BICYCLE("🚲 កង់", EntityType.MINECART, Material.WHEAT, 30, 0.3, 1);

    private final String displayName;
    private final EntityType entityType;
    private final Material fuelItem;
    private final int maxFuel;
    private final double speed;
    private final int maxPassengers;

    VisalMCType(String displayName, EntityType entityType, Material fuelItem,
                int maxFuel, double speed, int maxPassengers) {
        this.displayName = displayName;
        this.entityType = entityType;
        this.fuelItem = fuelItem;
        this.maxFuel = maxFuel;
        this.speed = speed;
        this.maxPassengers = maxPassengers;
    }

    public String getDisplayName() { return displayName; }
    public EntityType getEntityType() { return entityType; }
    public Material getFuelItem() { return fuelItem; }
    public int getMaxFuel() { return maxFuel; }
    public double getSpeed() { return speed; }
    public int getMaxPassengers() { return maxPassengers; }

    public static VisalMCType fromString(String name) {
        return switch (name.toLowerCase()) {
            case "car", "ឡាន" -> CAR;
            case "motorcycle", "moto", "ម៉ូតូ" -> MOTORCYCLE;
            case "bicycle", "bike", "កង់" -> BICYCLE;
            default -> null;
        };
    }
}
