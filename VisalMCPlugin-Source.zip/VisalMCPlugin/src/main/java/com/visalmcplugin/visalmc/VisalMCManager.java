package com.visalmcplugin.visalmc;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Minecart;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.scheduler.BukkitTask;
import org.bukkit.util.Vector;

import java.util.*;

public class VisalMCManager {

    private final VisalMCPlugin plugin;
    private final Map<UUID, VisalMCData> vehicles = new HashMap<>();
    private final Map<UUID, UUID> playerVehicles = new HashMap<>();
    private BukkitTask fuelTask = null;

    public VisalMCManager(VisalMCPlugin plugin) {
        this.plugin = plugin;
        startFuelTask();
    }

    public boolean spawnVehicle(Player player, VisalMCType type) {
        if (hasVehicle(player)) removeVehicle(player, false);

        Minecart cart = (Minecart) player.getLocation().getWorld()
                .spawnEntity(player.getLocation(), type.getEntityType());

        cart.setMaxSpeed(type.getSpeed());
        cart.setFlyingVelocityMod(new Vector(type.getSpeed(), 0.0, type.getSpeed()));
        cart.setDerailedVelocityMod(new Vector(type.getSpeed(), 0.1, type.getSpeed()));
        cart.setCustomName(ChatColor.YELLOW + type.getDisplayName()
                + ChatColor.GRAY + " [" + player.getName() + "]");
        cart.setCustomNameVisible(true);

        VisalMCData data = new VisalMCData(player.getUniqueId(), type, cart);
        vehicles.put(cart.getUniqueId(), data);
        playerVehicles.put(player.getUniqueId(), cart.getUniqueId());
        cart.addPassenger(player);

        player.sendMessage(ChatColor.GREEN + "✔ បានបង្កើត " + type.getDisplayName() + "§a !");
        player.sendMessage(ChatColor.GRAY + "⛽ Fuel: " + data.getFuelBar()
                + " §7" + data.getFuel() + "/" + data.getMaxFuel());
        player.sendMessage(ChatColor.YELLOW + "💡 ដាក់ §f" + getFuelName(type)
                + "§e ក្នុង off-hand រួចប្រើ §f/vehicle fuel §eដើម្បីបំពេញ!");
        return true;
    }

    public void removeVehicle(Player player, boolean msg) {
        UUID vid = playerVehicles.remove(player.getUniqueId());
        if (vid == null) return;
        VisalMCData data = vehicles.remove(vid);
        if (data != null && !data.getEntity().isDead()) {
            data.getEntity().eject();
            data.getEntity().remove();
        }
        if (msg) player.sendMessage(ChatColor.RED + "🚫 Vehicle បានដកចេញ!");
    }

    public void removeAll() {
        for (VisalMCData data : vehicles.values()) {
            if (!data.getEntity().isDead()) {
                data.getEntity().eject();
                data.getEntity().remove();
            }
        }
        vehicles.clear();
        playerVehicles.clear();
    }

    public boolean refuel(Player player) {
        UUID vid = playerVehicles.get(player.getUniqueId());
        if (vid == null) {
            player.sendMessage(ChatColor.RED + "❌ អ្នកមិនមាន vehicle ទេ!");
            return false;
        }
        VisalMCData data = vehicles.get(vid);
        if (data == null) return false;

        ItemStack offHand = player.getInventory().getItemInOffHand();
        if (offHand.getType() != data.getType().getFuelItem()) {
            player.sendMessage(ChatColor.RED + "❌ ត្រូវការ §e" + getFuelName(data.getType())
                    + "§c ក្នុង off-hand!");
            return false;
        }
        if (data.getFuel() >= data.getMaxFuel()) {
            player.sendMessage(ChatColor.YELLOW + "⚠ Fuel ពេញហើយ!");
            return false;
        }

        int add = data.getType().getMaxFuel() / 5;
        offHand.setAmount(offHand.getAmount() - 1);
        player.getInventory().setItemInOffHand(offHand);
        data.addFuel(add);

        player.sendMessage(ChatColor.GREEN + "⛽ បំពេញ fuel បានជោគជ័យ!");
        player.sendMessage(ChatColor.GRAY + "⛽ " + data.getFuelBar()
                + " §7" + data.getFuel() + "/" + data.getMaxFuel());
        return true;
    }

    private void startFuelTask() {
        fuelTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (Map.Entry<UUID, UUID> entry : new HashMap<>(playerVehicles).entrySet()) {
                Player player = Bukkit.getPlayer(entry.getKey());
                if (player == null) continue;

                VisalMCData data = vehicles.get(entry.getValue());
                if (data == null) continue;

                Entity entity = data.getEntity();
                if (!entity.getPassengers().contains(player)) continue;

                data.consumeFuel(1);

                if (data.getFuel() == 10) {
                    player.sendMessage(ChatColor.RED + "⚠ ⛽ Fuel ជិតអស់! (" + data.getFuel() + " នៅសល់)");
                }

                if (data.isEmpty()) {
                    player.sendMessage(ChatColor.RED + "❌ ⛽ Fuel អស់! Vehicle ឈប់ដំណើរ!");
                    entity.eject();
                    if (entity instanceof Minecart cart) {
                        cart.setVelocity(new Vector(0, 0, 0));
                        cart.setMaxSpeed(0);
                    }
                }

                if (data.getFuel() % 10 == 0 && data.getFuel() > 0) {
                    player.sendActionBar(net.kyori.adventure.text.Component.text(
                        "⛽ " + data.getFuelBar() + " §7" + data.getFuel() + "/" + data.getMaxFuel()
                    ));
                }
            }
        }, 100L, 100L);
    }

    public void stopTask() {
        if (fuelTask != null) fuelTask.cancel();
    }

    public boolean hasVehicle(Player player) {
        return playerVehicles.containsKey(player.getUniqueId());
    }

    public VisalMCData getData(Player player) {
        UUID vid = playerVehicles.get(player.getUniqueId());
        return vid != null ? vehicles.get(vid) : null;
    }

    public VisalMCData getDataByEntity(Entity entity) {
        return vehicles.get(entity.getUniqueId());
    }

    public boolean isVehicle(Entity entity) {
        return vehicles.containsKey(entity.getUniqueId());
    }

    private String getFuelName(VisalMCType type) {
        return switch (type) {
            case CAR -> "Iron Block";
            case MOTORCYCLE -> "Coal";
            case BICYCLE -> "Wheat";
        };
    }
}
