package com.visalmcplugin.visalmc;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.Arrays;
import java.util.List;

public class VisalMCCommand implements CommandExecutor, TabCompleter {

    private final VisalMCPlugin plugin;
    private final VisalMCManager vehicleManager;

    public VisalMCCommand(VisalMCPlugin plugin) {
        this.plugin = plugin;
        this.vehicleManager = plugin.getVehicleManager();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        if (!(sender instanceof Player player)) {
            sender.sendMessage(ChatColor.RED + "Only players can use this command!");
            return true;
        }

        if (!player.hasPermission("visalmc.use")) {
            player.sendMessage(ChatColor.RED + "អ្នកគ្មានសិទ្ធិប្រើ command នេះ!");
            return true;
        }

        // /vfuel command
        if (command.getName().equalsIgnoreCase("vfuel")) {
            vehicleManager.refuelVehicle(player, 0);
            return true;
        }

        // /vehicle command
        if (args.length == 0) {
            sendHelp(player);
            return true;
        }

        switch (args[0].toLowerCase()) {
            case "car", "ឡាន" -> vehicleManager.spawnVehicle(player, VisalMCType.CAR);
            case "motorcycle", "moto", "ម៉ូតូ" -> vehicleManager.spawnVehicle(player, VisalMCType.MOTORCYCLE);
            case "bicycle", "bike", "កង់" -> vehicleManager.spawnVehicle(player, VisalMCType.BICYCLE);
            case "remove", "delete", "លុប" -> vehicleManager.removeVehicle(player, true);
            case "fuel", "refuel", "⛽" -> vehicleManager.refuelVehicle(player, 0);
            case "info", "status" -> showVehicleInfo(player);
            case "list" -> showVehicleList(player);
            case "help" -> sendHelp(player);
            default -> {
                player.sendMessage(ChatColor.RED + "❌ Command មិនត្រឹមត្រូវ! ប្រើ /vehicle help");
            }
        }

        return true;
    }

    private void showVehicleInfo(Player player) {
        VisalMCData data = vehicleManager.getVehicleData(player);
        if (data == null) {
            player.sendMessage(ChatColor.RED + "❌ អ្នកមិនមាន vehicle ទេ!");
            return;
        }

        player.sendMessage(ChatColor.GOLD + "══════════════════════════");
        player.sendMessage(ChatColor.YELLOW + "  Vehicle: " + data.getType().getDisplayName());
        player.sendMessage(ChatColor.WHITE + "  ⛽ Fuel: " + data.getFuelBar()
                + ChatColor.WHITE + " " + data.getFuel() + "/" + data.getMaxFuel()
                + " (" + data.getFuelPercent() + "%)");
        player.sendMessage(ChatColor.WHITE + "  🚀 Speed: x" + data.getType().getSpeedMultiplier());
        player.sendMessage(ChatColor.WHITE + "  👥 Max Passengers: " + data.getType().getMaxPassengers());
        player.sendMessage(ChatColor.GOLD + "══════════════════════════");
    }

    private void showVehicleList(Player player) {
        player.sendMessage(ChatColor.GOLD + "══════════════════════════");
        player.sendMessage(ChatColor.YELLOW + "     🚗 Vehicle List 🚗");
        player.sendMessage(ChatColor.GOLD + "══════════════════════════");
        for (VisalMCType type : VisalMCType.values()) {
            player.sendMessage(ChatColor.AQUA + type.getDisplayName()
                    + ChatColor.GRAY + " — " + type.getDescription());
            player.sendMessage(ChatColor.GRAY + "   ⛽ Fuel Item: "
                    + ChatColor.WHITE + type.getFuelItem().name());
            player.sendMessage(ChatColor.GRAY + "   Spawn: "
                    + ChatColor.WHITE + "/vehicle " + type.name().toLowerCase());
        }
        player.sendMessage(ChatColor.GOLD + "══════════════════════════");
    }

    private void sendHelp(Player player) {
        player.sendMessage(ChatColor.GOLD + "══════════════════════════════");
        player.sendMessage(ChatColor.YELLOW + "     🚗 VisalMCPlugin Help 🚗");
        player.sendMessage(ChatColor.GOLD + "══════════════════════════════");
        player.sendMessage(ChatColor.AQUA + "/vehicle car" + ChatColor.WHITE + " — បង្កើតឡាន 🚗");
        player.sendMessage(ChatColor.AQUA + "/vehicle motorcycle" + ChatColor.WHITE + " — បង្កើតម៉ូតូ 🏍️");
        player.sendMessage(ChatColor.AQUA + "/vehicle bicycle" + ChatColor.WHITE + " — បង្កើតកង់ 🚲");
        player.sendMessage(ChatColor.AQUA + "/vehicle fuel" + ChatColor.WHITE + " — បំពេញ fuel ⛽");
        player.sendMessage(ChatColor.AQUA + "/vehicle info" + ChatColor.WHITE + " — មើលស្ថានភាព vehicle");
        player.sendMessage(ChatColor.AQUA + "/vehicle list" + ChatColor.WHITE + " — មើល vehicle ទាំងអស់");
        player.sendMessage(ChatColor.AQUA + "/vehicle remove" + ChatColor.WHITE + " — លុប vehicle");
        player.sendMessage(ChatColor.GOLD + "══════════════════════════════");
        player.sendMessage(ChatColor.YELLOW + "💡 ដាក់ fuel item ក្នុង off-hand ហើយប្រើ /vehicle fuel !");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return Arrays.asList("car", "motorcycle", "bicycle", "fuel", "remove", "info", "list", "help");
        }
        return List.of();
    }
}
