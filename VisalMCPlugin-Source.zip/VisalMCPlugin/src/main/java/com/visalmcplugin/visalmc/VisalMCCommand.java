package com.visalmcplugin.visalmc;

import org.bukkit.ChatColor;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.Player;

import java.util.Arrays;
import java.util.List;

public class VisalMCCommand implements CommandExecutor, TabCompleter {

    private final VisalMCPlugin plugin;
    private final VisalMCManager manager;

    public VisalMCCommand(VisalMCPlugin plugin) {
        this.plugin = plugin;
        this.manager = plugin.getManager();
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("Only players can use this!");
            return true;
        }
        if (!player.hasPermission("vehicle.use")) {
            player.sendMessage(ChatColor.RED + "អ្នកគ្មានសិទ្ធិ!");
            return true;
        }

        if (command.getName().equalsIgnoreCase("vfuel")) {
            manager.refuel(player);
            return true;
        }

        if (args.length == 0) { sendHelp(player); return true; }

        switch (args[0].toLowerCase()) {
            case "car", "ឡាន" -> manager.spawnVehicle(player, VisalMCType.CAR);
            case "motorcycle", "moto", "ម៉ូតូ" -> manager.spawnVehicle(player, VisalMCType.MOTORCYCLE);
            case "bicycle", "bike", "កង់" -> manager.spawnVehicle(player, VisalMCType.BICYCLE);
            case "remove", "លុប" -> manager.removeVehicle(player, true);
            case "fuel", "refuel" -> manager.refuel(player);
            case "info" -> showInfo(player);
            case "list" -> showList(player);
            default -> sendHelp(player);
        }
        return true;
    }

    private void showInfo(Player player) {
        VisalMCData data = manager.getData(player);
        if (data == null) {
            player.sendMessage(ChatColor.RED + "❌ អ្នកមិនមាន vehicle ទេ!");
            return;
        }
        player.sendMessage(ChatColor.GOLD + "══════════════════════════");
        player.sendMessage(ChatColor.YELLOW + "  " + data.getType().getDisplayName());
        player.sendMessage("  ⛽ Fuel: " + data.getFuelBar()
                + " §7" + data.getFuel() + "/" + data.getMaxFuel()
                + " (" + data.getFuelPercent() + "%)");
        player.sendMessage("  🚀 Speed: §fx" + data.getType().getSpeed());
        player.sendMessage(ChatColor.GOLD + "══════════════════════════");
    }

    private void showList(Player player) {
        player.sendMessage(ChatColor.GOLD + "══════════════════════════");
        player.sendMessage(ChatColor.YELLOW + "     🚗 Vehicle List");
        player.sendMessage(ChatColor.GOLD + "══════════════════════════");
        player.sendMessage(ChatColor.AQUA + "/vehicle car " + ChatColor.GRAY + "— ឡាន (Fuel: Iron Block)");
        player.sendMessage(ChatColor.AQUA + "/vehicle motorcycle " + ChatColor.GRAY + "— ម៉ូតូ (Fuel: Coal)");
        player.sendMessage(ChatColor.AQUA + "/vehicle bicycle " + ChatColor.GRAY + "— កង់ (Fuel: Wheat)");
        player.sendMessage(ChatColor.GOLD + "══════════════════════════");
    }

    private void sendHelp(Player player) {
        player.sendMessage(ChatColor.GOLD + "══════════════════════════════");
        player.sendMessage(ChatColor.YELLOW + "   🚗 VisalMCPlugin Help 🚗");
        player.sendMessage(ChatColor.GOLD + "══════════════════════════════");
        player.sendMessage(ChatColor.AQUA + "/vehicle car §f— §7បង្កើតឡាន 🚗");
        player.sendMessage(ChatColor.AQUA + "/vehicle motorcycle §f— §7បង្កើតម៉ូតូ 🏍️");
        player.sendMessage(ChatColor.AQUA + "/vehicle bicycle §f— §7បង្កើតកង់ 🚲");
        player.sendMessage(ChatColor.AQUA + "/vehicle fuel §f— §7បំពេញ fuel ⛽");
        player.sendMessage(ChatColor.AQUA + "/vehicle info §f— §7មើលស្ថានភាព");
        player.sendMessage(ChatColor.AQUA + "/vehicle remove §f— §7លុប vehicle");
        player.sendMessage(ChatColor.GOLD + "══════════════════════════════");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1)
            return Arrays.asList("car", "motorcycle", "bicycle", "fuel", "remove", "info", "list");
        return List.of();
    }
}
