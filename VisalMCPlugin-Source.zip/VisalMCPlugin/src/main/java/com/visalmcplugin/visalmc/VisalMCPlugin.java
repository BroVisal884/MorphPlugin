package com.visalmcplugin.visalmc;

import org.bukkit.plugin.java.JavaPlugin;

public class VisalMCPlugin extends JavaPlugin {

    private static VisalMCPlugin instance;
    private VisalMCManager vehicleManager;

    @Override
    public void onEnable() {
        instance = this;
        this.vehicleManager = new VisalMCManager(this);

        // Register commands
        VisalMCCommand vehicleCommand = new VisalMCCommand(this);
        getCommand("vehicle").setExecutor(vehicleCommand);
        getCommand("vehicle").setTabCompleter(vehicleCommand);
        getCommand("vfuel").setExecutor(vehicleCommand);

        // Register listeners
        getServer().getPluginManager().registerEvents(new VisalMCListener(this), this);

        getLogger().info("========================================");
        getLogger().info("  VisalMCPlugin enabled! v" + getDescription().getVersion());
        getLogger().info("  Commands: /vehicle car | motorcycle | bicycle");
        getLogger().info("========================================");
    }

    @Override
    public void onDisable() {
        if (vehicleManager != null) {
            vehicleManager.stopFuelTask();
            vehicleManager.removeAllVehicles();
        }
        getLogger().info("VisalMCPlugin disabled! All vehicles removed.");
    }

    public static VisalMCPlugin getInstance() { return instance; }
    public VisalMCManager getVehicleManager() { return vehicleManager; }
}
