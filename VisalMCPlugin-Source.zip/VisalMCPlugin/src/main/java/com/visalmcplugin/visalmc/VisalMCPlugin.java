package com.visalmcplugin.visalmc;

import org.bukkit.plugin.java.JavaPlugin;

public class VisalMCPlugin extends JavaPlugin {

    private static VisalMCPlugin instance;
    private VisalMCManager manager;

    @Override
    public void onEnable() {
        instance = this;
        this.manager = new VisalMCManager(this);

        VisalMCCommand cmd = new VisalMCCommand(this);
        getCommand("vehicle").setExecutor(cmd);
        getCommand("vehicle").setTabCompleter(cmd);
        getCommand("vfuel").setExecutor(cmd);

        getServer().getPluginManager().registerEvents(new VisalMCListener(this), this);

        getLogger().info("VisalMCPlugin v" + getDescription().getVersion() + " enabled!");
    }

    @Override
    public void onDisable() {
        if (manager != null) {
            manager.stopTask();
            manager.removeAll();
        }
        getLogger().info("VisalMCPlugin disabled!");
    }

    public static VisalMCPlugin getInstance() { return instance; }
    public VisalMCManager getManager() { return manager; }
    public VisalMCManager getVehicleManager() { return manager; }
}
