package com.visalmcplugin.visalmc;

import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Minecart;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.util.Vector;

import java.util.*;

public class VehicleManager {

    private final VisalMCPlugin plugin;

    // Entity UUID -> VehicleData
    private final Map<UUID, VehicleData> vehicles = new HashMap<>();
    // Player UUID -> Entity UUID (vehicle they own)
    private final Map<UUID, UUID> playerVehicles = new HashMap<>();

    // Fuel drain task ID
    private org.bukkit.scheduler.BukkitTask fuelTask = null;

    public VehicleManager(VisalMCPlugin plugin) {
        this.plugin = plugin;
        startFuelDrainTask();
    }

    // =============================================
    // Spawn Vehicle
    // =============================================
    public boolean spawnVehicle(Player player, VehicleType type) {
        // Remove old vehicle first
        if (hasVehicle(player)) {
            removeVehicle(player, false);
        }

        Location loc = player.getLocation();

        // Spawn minecart as base
        Minecart cart = (Minecart) loc.getWorld().spawnEntity(loc, type.getEntityType());

        // Config the cart
        cart.setMaxSpeed(type.getSpeedMultiplier());
        cart.setFlyingVelocityMod(new Vector(type.getSpeedMultiplier(), 0.0, type.getSpeedMultiplier()));
        cart.setDerailedVelocityMod(new Vector(type.getSpeedMultiplier(), 0.1, type.getSpeedMultiplier()));
        cart.setCustomName(ChatColor.YELLOW + type.getDisplayName() + ChatColor.GRAY + " [" + player.getName() + "]");
        cart.setCustomNameVisible(true);

        // Store vehicle data
        VehicleData data = new VehicleData(player.getUniqueId(), type, cart);
        vehicles.put(cart.getUniqueId(), data);
        playerVehicles.put(player.getUniqueId(), cart.getUniqueId());

        // Make player ride it
        cart.addPassenger(player);

        player.sendMessage(ChatColor.GREEN + "✔ បានបង្កើត " + type.getDisplayName() + ChatColor.GREEN + " !");
        player.sendMessage(ChatColor.GRAY + "⛽ Fuel: " + data.getFuelBar() + ChatColor.GRAY + " " + data.getFuel() + "/" + data.getMaxFuel());
        player.sendMessage(ChatColor.YELLOW + "💡 ចាក់ " + ChatColor.WHITE + getFuelItemName(type)
                + ChatColor.YELLOW + " ទៅក្នុង off-hand ដើម្បីបំពេញ fuel!");
        return true;
    }

    // =============================================
    // Remove Vehicle
    // =============================================
    public void removeVehicle(Player player, boolean sendMessage) {
        UUID vehicleId = playerVehicles.remove(player.getUniqueId());
        if (vehicleId == null) return;

        VehicleData data = vehicles.remove(vehicleId);
        if (data != null && !data.getEntity().isDead()) {
            data.getEntity().eject();
            data.getEntity().remove();
        }

        if (sendMessage) {
            player.sendMessage(ChatColor.RED + "🚫 Vehicle បានដកចេញ!");
        }
    }

    public void removeAllVehicles() {
        for (VehicleData data : vehicles.values()) {
            if (!data.getEntity().isDead()) {
                data.getEntity().eject();
                data.getEntity().remove();
            }
        }
        vehicles.clear();
        playerVehicles.clear();
    }

    // =============================================
    // Fuel System
    // =============================================
    public boolean refuelVehicle(Player player, int amount) {
        UUID vehicleId = playerVehicles.get(player.getUniqueId());
        if (vehicleId == null) return false;

        VehicleData data = vehicles.get(vehicleId);
        if (data == null) return false;

        VehicleType type = data.getType();
        ItemStack offHand = player.getInventory().getItemInOffHand();

        // Check if player has correct fuel item in off-hand
        if (offHand.getType() != type.getFuelItem()) {
            player.sendMessage(ChatColor.RED + "❌ ត្រូវការ " + ChatColor.YELLOW
                    + getFuelItemName(type) + ChatColor.RED + " ដើម្បីបំពេញ fuel!");
            return false;
        }

        if (data.getFuel() >= data.getMaxFuel()) {
            player.sendMessage(ChatColor.YELLOW + "⚠ Fuel ពេញហើយ! (" + data.getMaxFuel() + "/" + data.getMaxFuel() + ")");
            return false;
        }

        // Consume 1 fuel item, add fuel
        int fuelPerItem = type.getMaxFuel() / 5;
        offHand.setAmount(offHand.getAmount() - 1);
        player.getInventory().setItemInOffHand(offHand);
        data.addFuel(fuelPerItem);

        player.sendMessage(ChatColor.GREEN + "⛽ បំពេញ fuel !");
        player.sendMessage(ChatColor.GRAY + "⛽ Fuel: " + data.getFuelBar()
                + ChatColor.GRAY + " " + data.getFuel() + "/" + data.getMaxFuel());
        return true;
    }

    // Drain fuel every 5 seconds while riding
    private void startFuelDrainTask() {
        fuelTask = Bukkit.getScheduler().runTaskTimer(plugin, () -> {
            for (Map.Entry<UUID, UUID> entry : new HashMap<>(playerVehicles).entrySet()) {
                Player player = Bukkit.getPlayer(entry.getKey());
                if (player == null) continue;

                VehicleData data = vehicles.get(entry.getValue());
                if (data == null) continue;

                Entity vehicle = data.getEntity();

                // Only drain if player is riding
                if (!vehicle.getPassengers().contains(player)) continue;

                // Drain fuel
                data.consumeFuel(1);

                // Warn when low
                if (data.getFuel() == 10) {
                    player.sendMessage(ChatColor.RED + "⚠ ⛽ Fuel ជិតអស់ហើយ! (" + data.getFuel() + " នៅសល់)");
                }

                // Out of fuel
                if (data.isEmpty()) {
                    player.sendMessage(ChatColor.RED + "❌ ⛽ Fuel អស់ហើយ! Vehicle បានឈប់!");
                    vehicle.eject();
                    // Stop the cart
                    if (vehicle instanceof Minecart cart) {
                        cart.setVelocity(new Vector(0, 0, 0));
                        cart.setMaxSpeed(0);
                    }
                }

                // Show fuel action bar every 10 seconds
                if (data.getFuel() % 10 == 0 && data.getFuel() > 0) {
                    player.sendActionBar(net.kyori.adventure.text.Component.text(
                        "⛽ " + data.getFuelBar() + " §7" + data.getFuel() + "/" + data.getMaxFuel()
                    ));
                }
            }
        }, 100L, 100L); // every 5 seconds
    }

    // =============================================
    // Helpers
    // =============================================
    public boolean hasVehicle(Player player) {
        return playerVehicles.containsKey(player.getUniqueId());
    }

    public VehicleData getVehicleData(Player player) {
        UUID vid = playerVehicles.get(player.getUniqueId());
        return vid != null ? vehicles.get(vid) : null;
    }

    public VehicleData getVehicleByEntity(Entity entity) {
        return vehicles.get(entity.getUniqueId());
    }

    public boolean isVehicle(Entity entity) {
        return vehicles.containsKey(entity.getUniqueId());
    }

    private String getFuelItemName(VehicleType type) {
        return switch (type) {
            case CAR -> "Iron Block (⛏️)";
            case MOTORCYCLE -> "Coal (🪨)";
            case BICYCLE -> "Wheat (🌾)";
        };
    }

    public void stopFuelTask() {
        if (fuelTask != null) {
            fuelTask.cancel();
        }
    }
}
