package com.visalmcplugin.visalmc;

import org.bukkit.ChatColor;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.vehicle.VehicleDestroyEvent;
import org.bukkit.event.vehicle.VehicleEnterEvent;
import org.bukkit.event.vehicle.VehicleExitEvent;

public class VisalMCListener implements Listener {

    private final VisalMCPlugin plugin;
    private final VisalMCManager manager;

    public VisalMCListener(VisalMCPlugin plugin) {
        this.plugin = plugin;
        this.manager = plugin.getManager();
    }

    @EventHandler
    public void onEnter(VehicleEnterEvent event) {
        if (!(event.getEntered() instanceof Player player)) return;
        Entity entity = event.getVehicle();
        if (!manager.isVehicle(entity)) return;

        VisalMCData data = manager.getDataByEntity(entity);
        if (data == null) return;

        if (data.isEmpty()) {
            player.sendMessage(ChatColor.RED + "❌ ⛽ Fuel អស់! ចាក់ fuel ជាមុន!");
            event.setCancelled(true);
            return;
        }
        player.sendMessage(ChatColor.GREEN + "✔ ចូលជិះ " + data.getType().getDisplayName() + "§a !");
        player.sendActionBar(net.kyori.adventure.text.Component.text(
            "⛽ " + data.getFuelBar() + " §7" + data.getFuel() + "/" + data.getMaxFuel()
        ));
    }

    @EventHandler
    public void onExit(VehicleExitEvent event) {
        if (!(event.getExited() instanceof Player player)) return;
        Entity entity = event.getVehicle();
        if (!manager.isVehicle(entity)) return;

        VisalMCData data = manager.getDataByEntity(entity);
        if (data == null) return;

        player.sendMessage(ChatColor.YELLOW + "⚠ ចាកចេញពី " + data.getType().getDisplayName()
                + " §7(⛽ " + data.getFuel() + "/" + data.getMaxFuel() + ")");
    }

    @EventHandler
    public void onDestroy(VehicleDestroyEvent event) {
        Entity entity = event.getVehicle();
        if (!manager.isVehicle(entity)) return;

        VisalMCData data = manager.getDataByEntity(entity);
        if (data == null) return;

        if (event.getAttacker() instanceof Player attacker) {
            if (attacker.getUniqueId().equals(data.getOwnerUUID())) {
                manager.removeVehicle(attacker, false);
                attacker.sendMessage(ChatColor.RED + "🚫 " + data.getType().getDisplayName() + "§c ត្រូវបានបំផ្លាញ!");
                return;
            }
        }
        event.setCancelled(true);
    }

    @EventHandler
    public void onDamage(EntityDamageEvent event) {
        if (manager.isVehicle(event.getEntity())) {
            if (event.getCause() == EntityDamageEvent.DamageCause.ENTITY_ATTACK) {
                event.setCancelled(true);
            }
        }
    }
}
