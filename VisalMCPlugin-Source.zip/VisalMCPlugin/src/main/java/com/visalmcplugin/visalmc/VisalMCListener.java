package com.visalmcplugin.visalmc;

import org.bukkit.ChatColor;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageEvent;
import org.bukkit.event.vehicle.VehicleDestroyEvent;
import org.bukkit.event.vehicle.VehicleEnterEvent;
import org.bukkit.event.vehicle.VehicleExitEvent;

public class VisalMCListener implements Listener {

    private final VisalMCPlugin plugin;
    private final VisalMCManager vehicleManager;

    public VisalMCListener(VisalMCPlugin plugin) {
        this.plugin = plugin;
        this.vehicleManager = plugin.getVehicleManager();
    }

    @EventHandler
    public void onVehicleEnter(VehicleEnterEvent event) {
        if (!(event.getEntered() instanceof Player player)) return;
        Entity vehicle = event.getVehicle();
        if (!vehicleManager.isVehicle(vehicle)) return;

        VisalMCData data = vehicleManager.getVehicleByEntity(vehicle);
        if (data == null) return;

        if (data.isEmpty()) {
            player.sendMessage(ChatColor.RED + "❌ ⛽ Fuel អស់! ចាក់ fuel ជាមុន!");
            event.setCancelled(true);
            return;
        }

        player.sendMessage(ChatColor.GREEN + "✔ ចូលជិះ " + data.getType().getDisplayName() + ChatColor.GREEN + " !");
        player.sendActionBar(net.kyori.adventure.text.Component.text(
            "⛽ " + data.getFuelBar() + " §7" + data.getFuel() + "/" + data.getMaxFuel()
        ));
    }

    @EventHandler
    public void onVehicleExit(VehicleExitEvent event) {
        if (!(event.getExited() instanceof Player player)) return;
        Entity vehicle = event.getVehicle();
        if (!vehicleManager.isVehicle(vehicle)) return;

        VisalMCData data = vehicleManager.getVehicleByEntity(vehicle);
        if (data == null) return;

        if (!data.isEmpty()) {
            player.sendMessage(ChatColor.YELLOW + "⚠ អ្នកបានចាកចេញពី "
                    + data.getType().getDisplayName()
                    + ChatColor.GRAY + " (⛽ " + data.getFuel() + "/" + data.getMaxFuel() + ")");
        }
    }

    @EventHandler
    public void onVehicleDestroy(VehicleDestroyEvent event) {
        Entity vehicle = event.getVehicle();
        if (!vehicleManager.isVehicle(vehicle)) return;

        VisalMCData data = vehicleManager.getVehicleByEntity(vehicle);
        if (data == null) return;

        if (event.getAttacker() instanceof Player attacker) {
            if (attacker.getUniqueId().equals(data.getOwnerUUID())) {
                vehicleManager.removeVehicle(attacker, false);
                attacker.sendMessage(ChatColor.RED + "🚫 " + data.getType().getDisplayName()
                        + ChatColor.RED + " ត្រូវបានបំផ្លាញ!");
                return;
            }
        }
        event.setCancelled(true);
    }

    @EventHandler
    public void onEntityDamage(EntityDamageEvent event) {
        Entity entity = event.getEntity();
        if (vehicleManager.isVehicle(entity)) {
            if (event.getCause() == EntityDamageEvent.DamageCause.ENTITY_ATTACK) {
                event.setCancelled(true);
            }
        }
    }
}
