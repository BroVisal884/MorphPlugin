package com.kroma.morphplugin.listeners;

import com.kroma.morphplugin.MorphPlugin;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.PlayerDeathEvent;
import org.bukkit.event.player.PlayerJoinEvent;
import org.bukkit.event.player.PlayerQuitEvent;

public class MorphListener implements Listener {

    private final MorphPlugin plugin;

    public MorphListener(MorphPlugin plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onPlayerQuit(PlayerQuitEvent event) {
        Player player = event.getPlayer();
        boolean persist = plugin.getConfig().getBoolean("settings.persist-on-relog", false);
        if (!persist && plugin.getMorphManager().isMorphed(player.getUniqueId())) {
            plugin.getMorphManager().unmorphPlayer(player);
        }
    }

    @EventHandler
    public void onPlayerJoin(PlayerJoinEvent event) {
        Player player = event.getPlayer();
        if (plugin.getMorphManager().isMorphed(player.getUniqueId())) {
            var mobType = plugin.getMorphManager().getMorphType(player.getUniqueId());
            player.sendMessage("§6[MorphPlugin] You are still morphed as: §e"
                    + plugin.getMorphManager().formatMobName(mobType));
        }
    }

    @EventHandler
    public void onEntityDamage(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player attacker) {
            if (plugin.getMorphManager().isMorphed(attacker.getUniqueId())) {
                boolean allowInCombat = plugin.getConfig()
                        .getBoolean("settings.allow-morph-in-combat", false);
                if (!allowInCombat) {
                    attacker.sendMessage("§c[MorphPlugin] You are in combat - morphing is locked!");
                }
            }
        }
    }

    @EventHandler
    public void onPlayerDeath(PlayerDeathEvent event) {
        Player player = event.getEntity();
        if (plugin.getMorphManager().isMorphed(player.getUniqueId())) {
            plugin.getMorphManager().unmorphPlayer(player);
        }
    }
}
