package com.kroma.morphplugin;

import com.kroma.morphplugin.commands.MorphCommand;
import com.kroma.morphplugin.commands.MorphListCommand;
import com.kroma.morphplugin.commands.MorphReloadCommand;
import com.kroma.morphplugin.commands.UnmorphCommand;
import com.kroma.morphplugin.listeners.MorphListener;
import com.kroma.morphplugin.managers.MorphManager;
import org.bukkit.plugin.java.JavaPlugin;

/**
 * MorphPlugin — Main class
 * Allows players to transform into any Minecraft mob.
 *
 * Commands:
 *   /morph <mob>    — Transform into a mob
 *   /unmorph        — Return to normal form
 *   /morphlist      — List all available mobs
 *   /morphreload    — Reload config (admin only)
 *
 * @author KROMA
 * @version 1.0.0
 */
public class MorphPlugin extends JavaPlugin {

    private static MorphPlugin instance;
    private MorphManager morphManager;

    @Override
    public void onEnable() {
        instance = this;

        // Save default config
        saveDefaultConfig();

        // Initialize MorphManager
        morphManager = new MorphManager(this);

        // Register commands
        getCommand("morph").setExecutor(new MorphCommand(this));
        getCommand("unmorph").setExecutor(new UnmorphCommand(this));
        getCommand("morphlist").setExecutor(new MorphListCommand(this));
        getCommand("morphreload").setExecutor(new MorphReloadCommand(this));

        // Register listeners
        getServer().getPluginManager().registerEvents(new MorphListener(this), this);

        getLogger().info("=================================");
        getLogger().info("  MorphPlugin v1.0.0 enabled!");
        getLogger().info("  Made by KROMA");
        getLogger().info("=================================");
    }

    @Override
    public void onDisable() {
        // Unmorph all players on shutdown
        if (morphManager != null) {
            morphManager.unmorphAll();
        }
        getLogger().info("MorphPlugin disabled. All players unmorphed.");
    }

    public static MorphPlugin getInstance() {
        return instance;
    }

    public MorphManager getMorphManager() {
        return morphManager;
    }
}
