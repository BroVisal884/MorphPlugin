package com.kroma.morphplugin.commands;

import com.kroma.morphplugin.MorphPlugin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

/**
 * /morph <mob> — Transform into any mob.
 */
public class MorphCommand implements CommandExecutor, TabCompleter {

    private final MorphPlugin plugin;

    public MorphCommand(MorphPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        // Only players can morph
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§c[MorphPlugin] Only players can use this command.");
            return true;
        }

        // Check permission
        if (!player.hasPermission("morph.use")) {
            player.sendMessage("§c✘ You do not have permission to use /morph.");
            return true;
        }

        // Check args
        if (args.length == 0) {
            player.sendMessage("§e📖 Usage: §f/morph <mob>");
            player.sendMessage("§e📖 Example: §f/morph zombie");
            player.sendMessage("§e📖 Use §f/morphlist §eto see all available mobs.");
            return true;
        }

        String mobInput = args[0].toUpperCase();

        // Check blocked mobs
        List<String> blocked = plugin.getConfig().getStringList("blocked-mobs");
        if (blocked.contains(mobInput)) {
            player.sendMessage("§c✘ You cannot morph into §e" + args[0] + "§c.");
            return true;
        }

        // Check admin-only mobs
        List<String> adminOnly = plugin.getConfig().getStringList("admin-only-mobs");
        if (adminOnly.contains(mobInput) && !player.hasPermission("morph.admin")) {
            String msg = plugin.getConfig().getString("messages.no-permission",
                    "&cYou do not have permission to morph into &e%mob%&c.")
                    .replace("%mob%", args[0])
                    .replace("&", "§");
            player.sendMessage(msg);
            return true;
        }

        // Parse EntityType
        EntityType entityType;
        try {
            entityType = EntityType.valueOf(mobInput);
        } catch (IllegalArgumentException e) {
            String msg = plugin.getConfig().getString("messages.invalid-mob",
                    "&c✘ Unknown mob: &e%mob%&c. Use /morphlist to see all mobs.")
                    .replace("%mob%", args[0])
                    .replace("&", "§");
            player.sendMessage(msg);
            return true;
        }

        // Must be alive & spawnable
        if (!entityType.isAlive() || !entityType.isSpawnable()) {
            player.sendMessage("§c✘ §e" + args[0] + " §cis not a valid mob to morph into.");
            return true;
        }

        // Morph the player
        plugin.getMorphManager().morphPlayer(player, entityType);
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> suggestions = new ArrayList<>();
        if (args.length == 1) {
            String input = args[0].toUpperCase();
            for (EntityType type : plugin.getMorphManager().getAvailableMobs()) {
                if (type.name().startsWith(input)) {
                    suggestions.add(type.name().toLowerCase());
                }
            }
        }
        return suggestions;
    }
}
