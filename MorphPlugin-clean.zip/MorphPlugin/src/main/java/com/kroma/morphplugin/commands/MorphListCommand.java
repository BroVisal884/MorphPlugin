package com.kroma.morphplugin.commands;

import com.kroma.morphplugin.MorphPlugin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.EntityType;

import java.util.List;

/**
 * /morphlist — List all available mobs to morph into.
 */
public class MorphListCommand implements CommandExecutor {

    private final MorphPlugin plugin;

    public MorphListCommand(MorphPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        if (!sender.hasPermission("morph.use")) {
            sender.sendMessage("§c✘ You do not have permission.");
            return true;
        }

        List<EntityType> mobs = plugin.getMorphManager().getAvailableMobs();

        sender.sendMessage("§6&l=============================".replace("&", "§"));
        sender.sendMessage("§6§l  🐾 Available Mobs (" + mobs.size() + ")");
        sender.sendMessage("§6§l=============================");

        // Display in rows of 4
        StringBuilder row = new StringBuilder();
        int count = 0;
        for (EntityType type : mobs) {
            String name = plugin.getMorphManager().formatMobName(type);
            row.append("§e").append(name).append("  ");
            count++;
            if (count % 4 == 0) {
                sender.sendMessage(row.toString().trim());
                row = new StringBuilder();
            }
        }
        if (!row.isEmpty()) {
            sender.sendMessage(row.toString().trim());
        }

        sender.sendMessage("§6§l=============================");
        sender.sendMessage("§7Usage: §f/morph <mob name>");
        sender.sendMessage("§7Example: §f/morph zombie");

        return true;
    }
}
