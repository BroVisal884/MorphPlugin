package com.kroma.morphplugin.managers;

import com.kroma.morphplugin.MorphPlugin;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.format.NamedTextColor;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;

import java.util.*;

public class MorphManager {

    private final MorphPlugin plugin;
    private final Map<UUID, EntityType> morphedPlayers = new HashMap<>();
    private final Map<UUID, Long> cooldowns = new HashMap<>();

    public MorphManager(MorphPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean morphPlayer(Player player, EntityType entityType) {
        UUID uuid = player.getUniqueId();

        if (isOnCooldown(uuid)) {
            long remaining = getRemainingCooldown(uuid);
            player.sendMessage(Component.text("Please wait " + remaining + " seconds before morphing again.", NamedTextColor.RED));
            return false;
        }

        morphedPlayers.put(uuid, entityType);
        cooldowns.put(uuid, System.currentTimeMillis());

        applyMorphEffect(player, entityType);

        player.sendMessage(Component.text("You have morphed into " + formatMobName(entityType) + "!", NamedTextColor.GREEN));

        if (plugin.getConfig().getBoolean("settings.show-action-bar", true)) {
            player.sendActionBar(Component.text("Morphed: " + formatMobName(entityType), NamedTextColor.GOLD));
        }

        if (plugin.getConfig().getBoolean("settings.play-sound", true)) {
            player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 1.2f);
        }

        return true;
    }

    private void applyMorphEffect(Player player, EntityType entityType) {
        String mobName = formatMobName(entityType);
        player.setDisplayName("§8[§6" + mobName + "§8] §f" + player.getName());
        player.setPlayerListName("§8[§6" + mobName + "§8] §f" + player.getName());

        player.addPotionEffect(new org.bukkit.potion.PotionEffect(
                org.bukkit.potion.PotionEffectType.GLOWING, 60, 0, true, false));

        org.bukkit.World world = player.getWorld();
        org.bukkit.entity.Entity mob = world.spawnEntity(player.getLocation(), entityType);

        if (mob instanceof org.bukkit.entity.LivingEntity living) {
            living.setAI(false);
            living.setInvulnerable(true);
            living.setSilent(true);
            living.setCustomNameVisible(false);
            mob.addPassenger(player);

            plugin.getServer().getScheduler().runTaskLater(plugin, () -> {
                if (mob.isValid()) mob.remove();
            }, 60L);
        }
    }

    public boolean unmorphPlayer(Player player) {
        UUID uuid = player.getUniqueId();

        if (!isMorphed(uuid)) {
            player.sendMessage(Component.text("You are not currently morphed.", NamedTextColor.RED));
            return false;
        }

        morphedPlayers.remove(uuid);
        player.setDisplayName(player.getName());
        player.setPlayerListName(player.getName());
        player.removePotionEffect(org.bukkit.potion.PotionEffectType.GLOWING);

        player.sendMessage(Component.text("You have returned to your normal form!", NamedTextColor.GREEN));

        if (plugin.getConfig().getBoolean("settings.show-action-bar", true)) {
            player.sendActionBar(Component.text("Returned to normal form!", NamedTextColor.GREEN));
        }

        if (plugin.getConfig().getBoolean("settings.play-sound", true)) {
            player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_PLAYER_LEVELUP, 1.0f, 1.5f);
        }

        return true;
    }

    public void unmorphAll() {
        for (UUID uuid : morphedPlayers.keySet()) {
            Player player = plugin.getServer().getPlayer(uuid);
            if (player != null && player.isOnline()) {
                player.setDisplayName(player.getName());
                player.setPlayerListName(player.getName());
                player.removePotionEffect(org.bukkit.potion.PotionEffectType.GLOWING);
                player.sendMessage(Component.text("Plugin disabled - you have been unmorphed.", NamedTextColor.YELLOW));
            }
        }
        morphedPlayers.clear();
    }

    public boolean isMorphed(UUID uuid) {
        return morphedPlayers.containsKey(uuid);
    }

    public EntityType getMorphType(UUID uuid) {
        return morphedPlayers.get(uuid);
    }

    public boolean isOnCooldown(UUID uuid) {
        if (!cooldowns.containsKey(uuid)) return false;
        int cooldownMs = plugin.getConfig().getInt("settings.morph-cooldown", 5) * 1000;
        return (System.currentTimeMillis() - cooldowns.get(uuid)) < cooldownMs;
    }

    public long getRemainingCooldown(UUID uuid) {
        if (!cooldowns.containsKey(uuid)) return 0;
        int cooldownMs = plugin.getConfig().getInt("settings.morph-cooldown", 5) * 1000;
        long elapsed = System.currentTimeMillis() - cooldowns.get(uuid);
        return Math.max(0, (cooldownMs - elapsed) / 1000);
    }

    public String formatMobName(EntityType type) {
        String name = type.name().replace("_", " ");
        StringBuilder result = new StringBuilder();
        for (String word : name.split(" ")) {
            if (!word.isEmpty()) {
                result.append(Character.toUpperCase(word.charAt(0)))
                      .append(word.substring(1).toLowerCase())
                      .append(" ");
            }
        }
        return result.toString().trim();
    }

    public List<EntityType> getAvailableMobs() {
        List<EntityType> mobs = new ArrayList<>();
        List<String> blocked = plugin.getConfig().getStringList("blocked-mobs");
        for (EntityType type : EntityType.values()) {
            if (type.isAlive() && type.isSpawnable() && !blocked.contains(type.name())) {
                mobs.add(type);
            }
        }
        return mobs;
    }
}
