package com.kroma.morphplugin.commands;

import com.kroma.morphplugin.MorphPlugin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

/**
 * /unmorph — Return to normal form.
 */
public class UnmorphCommand implements CommandExecutor {

    private final MorphPlugin plugin;

    public UnmorphCommand(MorphPlugin plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {

        if (!(sender instanceof Player player)) {
            sender.sendMessage("§c[MorphPlugin] Only players can use this command.");
            return true;
        }

        if (!player.hasPermission("morph.use")) {
            player.sendMessage("§c✘ You do not have permission to use /unmorph.");
            return true;
        }

        plugin.getMorphManager().unmorphPlayer(player);
        return true;
    }
}
