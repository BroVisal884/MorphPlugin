package com.kroma.morphplugin.commands;

import com.kroma.morphplugin.MorphPlugin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public class MorphCommand implements CommandExecutor, TabCompleter {
    private final MorphPlugin plugin;
    public MorphCommand(MorphPlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cOnly players can use this command.");
            return true;
        }
        if (!player.hasPermission("morph.use")) {
            player.sendMessage("§cYou don't have permission.");
            return true;
        }
        if (args.length == 0) {
            player.sendMessage("§eUsage: /morph <mob>");
            return true;
        }
        try {
            EntityType type = EntityType.valueOf(args[0].toUpperCase());
            plugin.getMorphManager().morphPlayer(player, type);
        } catch (IllegalArgumentException e) {
            player.sendMessage("§cUnknown mob: §e" + args[0]);
        }
        return true;
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        List<String> list = new ArrayList<>();
        if (args.length == 1) {
            for (EntityType type : EntityType.values()) {
                if (type.isAlive() && type.isSpawnable())
                    if (type.name().toLowerCase().startsWith(args[0].toLowerCase()))
                        list.add(type.name().toLowerCase());
            }
        }
        return list;
    }
}
