package com.kroma.morphplugin.commands;

import com.kroma.morphplugin.MorphPlugin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;

public class MorphReloadCommand implements CommandExecutor {
    private final MorphPlugin plugin;
    public MorphReloadCommand(MorphPlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!sender.hasPermission("morph.admin")) {
            sender.sendMessage("§cNo permission.");
            return true;
        }
        plugin.reloadConfig();
        sender.sendMessage("§a[MorphPlugin] Config reloaded!");
        return true;
    }
}
