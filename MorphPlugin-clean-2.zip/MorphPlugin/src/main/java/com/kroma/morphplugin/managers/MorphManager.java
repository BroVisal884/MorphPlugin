package com.kroma.morphplugin.managers;

import com.kroma.morphplugin.MorphPlugin;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;

import java.util.*;

public class MorphManager {

    private final MorphPlugin plugin;
    private final Map<UUID, EntityType> morphedPlayers = new HashMap<>();
    private final Map<UUID, Long> cooldowns = new HashMap<>();
    private final Map<UUID, Entity> morphEntities = new HashMap<>();
    private final Map<UUID, List<BukkitTask>> morphTasks = new HashMap<>();

    public MorphManager(MorphPlugin plugin) {
        this.plugin = plugin;
    }

    public boolean morphPlayer(Player player, EntityType entityType) {
        UUID uuid = player.getUniqueId();

        if (isOnCooldown(uuid)) {
            long remaining = getRemainingCooldown(uuid);
            player.sendMessage("§c[MorphPlugin] Please wait §e" + remaining + "§c seconds.");
            return false;
        }

        if (isMorphed(uuid)) {
            removeMorph(uuid);
        }

        morphedPlayers.put(uuid, entityType);
        cooldowns.put(uuid, System.currentTimeMillis());

        applyMorphEffect(player, entityType);
        applyMobAbilities(player, entityType);

        player.sendMessage("§a[MorphPlugin] Morphed into §e" + formatMobName(entityType) + "§a!");
        if (plugin.getConfig().getBoolean("settings.play-sound", true)) {
            player.playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1.2f);
        }
        return true;
    }

    private void applyMorphEffect(Player player, EntityType entityType) {
        UUID uuid = player.getUniqueId();
        String mobName = formatMobName(entityType);
        player.setDisplayName("§8[§6" + mobName + "§8] §f" + player.getName());
        player.setPlayerListName("§8[§6" + mobName + "§8] §f" + player.getName());
        player.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, Integer.MAX_VALUE, 0, true, false));

        World world = player.getWorld();
        Entity mob = world.spawnEntity(player.getLocation(), entityType);
        if (mob instanceof LivingEntity living) {
            living.setAI(false);
            living.setInvulnerable(true);
            living.setSilent(true);
            living.setCustomNameVisible(false);
            mob.addPassenger(player);
        }
        morphEntities.put(uuid, mob);
    }

    private void applyMobAbilities(Player player, EntityType type) {
        UUID uuid = player.getUniqueId();
        List<BukkitTask> tasks = new ArrayList<>();
        removeAllPotionEffects(player);

        switch (type) {
            // ===== FLYING MOBS =====
            case BEE, BAT, PARROT, ALLAY -> {
                player.setAllowFlight(true);
                player.sendMessage("§b✦ Ability: §fFly freely!");
            }
            case PHANTOM -> {
                player.setAllowFlight(true);
                player.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, Integer.MAX_VALUE, 0, true, false));
                player.sendMessage("§b✦ Ability: §fFly + Night Vision!");
            }
            case GHAST -> {
                player.setAllowFlight(true);
                player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, Integer.MAX_VALUE, 1, true, false));
                player.sendMessage("§b✦ Ability: §fFly + High Resistance!");
            }
            case BLAZE -> {
                player.setAllowFlight(true);
                player.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, Integer.MAX_VALUE, 0, true, false));
                player.setFireTicks(0);
                player.sendMessage("§b✦ Ability: §fFly + Fire Immunity!");
            }
            case ENDER_DRAGON -> {
                player.setAllowFlight(true);
                player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, Integer.MAX_VALUE, 4, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, Integer.MAX_VALUE, 2, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.HEALTH_BOOST, Integer.MAX_VALUE, 9, true, false));
                player.sendMessage("§b✦ Ability: §fFly + Godlike Strength + Health!");
            }
            case WITHER -> {
                player.setAllowFlight(true);
                player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, Integer.MAX_VALUE, 3, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, Integer.MAX_VALUE, 1, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.WITHER, Integer.MAX_VALUE, 0, true, false));
                player.sendMessage("§b✦ Ability: §fFly + Wither Aura + Strength!");
            }
            case VEX -> {
                player.setAllowFlight(true);
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 2, true, false));
                player.sendMessage("§b✦ Ability: §fFly + Super Speed!");
            }

            // ===== WATER MOBS =====
            case DOLPHIN -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.DOLPHINS_GRACE, Integer.MAX_VALUE, 0, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.WATER_BREATHING, Integer.MAX_VALUE, 0, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 1, true, false));
                player.sendMessage("§b✦ Ability: §fSwim Fast + Breathe Underwater!");
            }
            case SQUID, GLOW_SQUID -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.WATER_BREATHING, Integer.MAX_VALUE, 0, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, Integer.MAX_VALUE, 0, true, false));
                player.sendMessage("§b✦ Ability: §fBreathe Underwater + Night Vision!");
            }
            case ELDER_GUARDIAN, GUARDIAN -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.WATER_BREATHING, Integer.MAX_VALUE, 0, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, Integer.MAX_VALUE, 2, true, false));
                player.sendMessage("§b✦ Ability: §fBreathe Underwater + High Defense!");
            }
            case AXOLOTL -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.WATER_BREATHING, Integer.MAX_VALUE, 0, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, Integer.MAX_VALUE, 1, true, false));
                player.sendMessage("§b✦ Ability: §fBreathe Underwater + Regeneration!");
            }
            case TURTLE -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.WATER_BREATHING, Integer.MAX_VALUE, 0, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, Integer.MAX_VALUE, 3, true, false));
                player.sendMessage("§b✦ Ability: §fBreathe Underwater + Super Shell Defense!");
            }

            // ===== STRONG / TANK MOBS =====
            case IRON_GOLEM -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, Integer.MAX_VALUE, 4, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, Integer.MAX_VALUE, 2, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.HEALTH_BOOST, Integer.MAX_VALUE, 9, true, false));
                player.sendMessage("§b✦ Ability: §fMax Defense + Strength + 20 Extra Hearts!");
            }
            case RAVAGER -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, Integer.MAX_VALUE, 3, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, Integer.MAX_VALUE, 2, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.HEALTH_BOOST, Integer.MAX_VALUE, 4, true, false));
                player.sendMessage("§b✦ Ability: §fBrute Strength + Tough Defense!");
            }
            case ELDER_GUARDIAN -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, Integer.MAX_VALUE, 3, true, false));
                player.sendMessage("§b✦ Ability: §fHigh Defense!");
            }
            case SHULKER -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, Integer.MAX_VALUE, 4, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.LEVITATION, 1, 0, true, false));
                player.sendMessage("§b✦ Ability: §fMax Shell Defense!");
            }
            case WARDEN -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, Integer.MAX_VALUE, 4, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, Integer.MAX_VALUE, 4, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.HEALTH_BOOST, Integer.MAX_VALUE, 14, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.DARKNESS, Integer.MAX_VALUE, 0, true, false));
                player.sendMessage("§b✦ Ability: §fMax Everything - YOU ARE THE WARDEN!");
            }

            // ===== FAST MOBS =====
            case HORSE, DONKEY, MULE -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 3, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, Integer.MAX_VALUE, 2, true, false));
                player.sendMessage("§b✦ Ability: §fSuper Speed + High Jump!");
            }
            case RABBIT -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 2, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, Integer.MAX_VALUE, 5, true, false));
                player.sendMessage("§b✦ Ability: §fSpeed + Mega Jump!");
            }
            case WOLF -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 1, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, Integer.MAX_VALUE, 1, true, false));
                player.sendMessage("§b✦ Ability: §fSpeed + Pack Strength!");
            }
            case OCELOT, CAT -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 2, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, Integer.MAX_VALUE, 3, true, false));
                player.sendMessage("§b✦ Ability: §fAgile Speed + High Jump!");
            }

            // ===== SPECIAL / UNIQUE MOBS =====
            case ENDERMAN -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 1, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, Integer.MAX_VALUE, 0, true, false));
                player.sendMessage("§b✦ Ability: §fNight Vision + Speed! Use /morph teleport to teleport!");
                // Teleport task - right click to teleport (Enderman style)
                BukkitTask task = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
                    if (!isMorphed(player.getUniqueId())) return;
                    if (player.isSneaking()) {
                        org.bukkit.block.Block target = player.getTargetBlock(null, 50);
                        if (target != null) {
                            player.teleport(target.getLocation().add(0, 1, 0));
                            player.getWorld().spawnParticle(Particle.PORTAL, player.getLocation(), 30);
                            player.playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1f);
                        }
                    }
                }, 0L, 10L);
                tasks.add(task);
            }
            case SPIDER, CAVE_SPIDER -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 1, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, Integer.MAX_VALUE, 0, true, false));
                if (type == EntityType.CAVE_SPIDER) {
                    player.addPotionEffect(new PotionEffect(PotionEffectType.POISON, Integer.MAX_VALUE, 0, true, false));
                }
                player.sendMessage("§b✦ Ability: §fSpeed + Night Vision" + (type == EntityType.CAVE_SPIDER ? " + Poison Aura!" : "!"));
            }
            case CREEPER -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 0, true, false));
                player.sendMessage("§b✦ Ability: §fSneak Mode - Crouch to trigger explosion warning!");
                BukkitTask task = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
                    if (!isMorphed(player.getUniqueId())) return;
                    if (player.isSneaking()) {
                        player.getWorld().spawnParticle(Particle.SMOKE, player.getLocation(), 10);
                        player.playSound(player.getLocation(), Sound.ENTITY_CREEPER_PRIMED, 0.5f, 1f);
                    }
                }, 0L, 20L);
                tasks.add(task);
            }
            case WITCH -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 0, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, Integer.MAX_VALUE, 0, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, Integer.MAX_VALUE, 0, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.WATER_BREATHING, Integer.MAX_VALUE, 0, true, false));
                player.sendMessage("§b✦ Ability: §fWitch Resistance (Fire, Water, Regen)!");
            }
            case SKELETON, STRAY -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 0, true, false));
                if (type == EntityType.STRAY) {
                    player.addPotionEffect(new PotionEffect(PotionEffectType.SLOWNESS, 1, 0, true, false));
                }
                player.sendMessage("§b✦ Ability: §fSkeleton Speed" + (type == EntityType.STRAY ? " + Frost Aura!" : "!"));
            }
            case ZOMBIE, ZOMBIE_VILLAGER, HUSK -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, Integer.MAX_VALUE, 0, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, Integer.MAX_VALUE, 0, true, false));
                if (type == EntityType.HUSK) {
                    player.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, Integer.MAX_VALUE, 0, true, false));
                }
                player.sendMessage("§b✦ Ability: §fZombie Strength + Resistance!");
            }
            case SILVERFISH -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 3, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.HASTE, Integer.MAX_VALUE, 2, true, false));
                player.sendMessage("§b✦ Ability: §fSuper Speed + Haste!");
            }
            case SLIME, MAGMA_CUBE -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, Integer.MAX_VALUE, 4, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, Integer.MAX_VALUE, 1, true, false));
                if (type == EntityType.MAGMA_CUBE) {
                    player.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, Integer.MAX_VALUE, 0, true, false));
                }
                player.sendMessage("§b✦ Ability: §fMega Jump + Resistance!");
            }
            case POLAR_BEAR -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, Integer.MAX_VALUE, 2, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, Integer.MAX_VALUE, 1, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 0, true, false));
                player.sendMessage("§b✦ Ability: §fBear Strength + Defense!");
            }
            case SNOW_GOLEM -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 1, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.WEAKNESS, Integer.MAX_VALUE, 0, true, false));
                player.sendMessage("§b✦ Ability: §fSnow Trail Speed!");
            }
            case VILLAGER -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.HERO_OF_THE_VILLAGE, Integer.MAX_VALUE, 0, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.LUCK, Integer.MAX_VALUE, 0, true, false));
                player.sendMessage("§b✦ Ability: §fHero of the Village + Luck!");
            }
            case PIGLIN, PIGLIN_BRUTE -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, Integer.MAX_VALUE, 0, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, Integer.MAX_VALUE, 1, true, false));
                player.sendMessage("§b✦ Ability: §fFire Resistance + Nether Strength!");
            }
            case HOGLIN, ZOGLIN -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, Integer.MAX_VALUE, 2, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.HEALTH_BOOST, Integer.MAX_VALUE, 3, true, false));
                player.sendMessage("§b✦ Ability: §fBrute Force + Extra Health!");
            }
            case STRIDER -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, Integer.MAX_VALUE, 0, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 0, true, false));
                player.sendMessage("§b✦ Ability: §fWalk on Lava + Fire Immune!");
            }
            case GOAT -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, Integer.MAX_VALUE, 5, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, Integer.MAX_VALUE, 0, true, false));
                player.sendMessage("§b✦ Ability: §fMega Jump + Ram Strength!");
            }
            case FROG -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, Integer.MAX_VALUE, 3, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.WATER_BREATHING, Integer.MAX_VALUE, 0, true, false));
                player.sendMessage("§b✦ Ability: §fHigh Jump + Water Breathing!");
            }
            case SNIFFER -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.LUCK, Integer.MAX_VALUE, 2, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.HEALTH_BOOST, Integer.MAX_VALUE, 4, true, false));
                player.sendMessage("§b✦ Ability: §fHigh Luck + Extra Hearts!");
            }
            default -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 0, true, false));
                player.sendMessage("§b✦ Ability: §fBasic Speed!");
            }
        }

        morphTasks.put(player.getUniqueId(), tasks);
    }

    private void removeAllPotionEffects(Player player) {
        for (PotionEffect effect : player.getActivePotionEffects()) {
            player.removePotionEffect(effect.getType());
        }
    }

    private void removeMorph(UUID uuid) {
        // Cancel tasks
        List<BukkitTask> tasks = morphTasks.getOrDefault(uuid, new ArrayList<>());
        for (BukkitTask task : tasks) task.cancel();
        morphTasks.remove(uuid);

        // Remove mob
        Entity mob = morphEntities.get(uuid);
        if (mob != null && mob.isValid()) {
            mob.eject();
            mob.remove();
        }
        morphEntities.remove(uuid);
        morphedPlayers.remove(uuid);
    }

    public boolean unmorphPlayer(Player player) {
        UUID uuid = player.getUniqueId();
        if (!isMorphed(uuid)) {
            player.sendMessage("§c[MorphPlugin] You are not morphed.");
            return false;
        }

        removeMorph(uuid);

        player.setDisplayName(player.getName());
        player.setPlayerListName(player.getName());
        player.removePotionEffect(PotionEffectType.GLOWING);
        removeAllPotionEffects(player);

        player.setAllowFlight(player.getGameMode() == GameMode.CREATIVE
                || player.getGameMode() == GameMode.SPECTATOR);

        player.sendMessage("§a[MorphPlugin] Returned to normal form!");
        if (plugin.getConfig().getBoolean("settings.play-sound", true)) {
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.5f);
        }
        return true;
    }

    public void unmorphAll() {
        for (UUID uuid : new HashSet<>(morphedPlayers.keySet())) {
            Player player = plugin.getServer().getPlayer(uuid);
            removeMorph(uuid);
            if (player != null && player.isOnline()) {
                player.setDisplayName(player.getName());
                player.setPlayerListName(player.getName());
                removeAllPotionEffects(player);
                player.setAllowFlight(player.getGameMode() == GameMode.CREATIVE
                        || player.getGameMode() == GameMode.SPECTATOR);
                player.sendMessage("§e[MorphPlugin] Plugin disabled - unmorphed.");
            }
        }
        morphedPlayers.clear();
    }

    public boolean isMorphed(UUID uuid) { return morphedPlayers.containsKey(uuid); }
    public EntityType getMorphType(UUID uuid) { return morphedPlayers.get(uuid); }

    public boolean isOnCooldown(UUID uuid) {
        if (!cooldowns.containsKey(uuid)) return false;
        int ms = plugin.getConfig().getInt("settings.morph-cooldown", 5) * 1000;
        return (System.currentTimeMillis() - cooldowns.get(uuid)) < ms;
    }

    public long getRemainingCooldown(UUID uuid) {
        if (!cooldowns.containsKey(uuid)) return 0;
        int ms = plugin.getConfig().getInt("settings.morph-cooldown", 5) * 1000;
        return Math.max(0, (ms - (System.currentTimeMillis() - cooldowns.get(uuid))) / 1000);
    }

    public String formatMobName(EntityType type) {
        StringBuilder result = new StringBuilder();
        for (String word : type.name().replace("_", " ").split(" ")) {
            if (!word.isEmpty())
                result.append(Character.toUpperCase(word.charAt(0)))
                      .append(word.substring(1).toLowerCase()).append(" ");
        }
        return result.toString().trim();
    }

    public List<EntityType> getAvailableMobs() {
        List<EntityType> mobs = new ArrayList<>();
        List<String> blocked = plugin.getConfig().getStringList("blocked-mobs");
        for (EntityType type : EntityType.values())
            if (type.isAlive() && type.isSpawnable() && !blocked.contains(type.name()))
                mobs.add(type);
        return mobs;
    }
}
