package com.kroma.morphplugin.managers;

import com.kroma.morphplugin.MorphPlugin;
import org.bukkit.*;
import org.bukkit.entity.*;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitTask;

import java.lang.reflect.Method;
import java.util.*;

public class MorphManager {

    private final MorphPlugin plugin;
    private final boolean hasLibsDisguises;
    private final Map<UUID, EntityType> morphedPlayers = new HashMap<>();
    private final Map<UUID, Long> cooldowns = new HashMap<>();
    private final Map<UUID, List<BukkitTask>> morphTasks = new HashMap<>();

    public MorphManager(MorphPlugin plugin) {
        this.plugin = plugin;
        boolean found = false;
        try {
            Class.forName("me.libraryaddict.disguise.DisguiseAPI");
            found = true;
            plugin.getLogger().info("[MorphPlugin] LibsDisguises found! Visual disguise enabled.");
        } catch (ClassNotFoundException e) {
            plugin.getLogger().warning("[MorphPlugin] LibsDisguises not found. Install it for visual disguise!");
        }
        this.hasLibsDisguises = found;
    }

    public boolean morphPlayer(Player player, EntityType entityType) {
        UUID uuid = player.getUniqueId();
        if (isOnCooldown(uuid)) {
            player.sendMessage("§c[MorphPlugin] Wait §e" + getRemainingCooldown(uuid) + "§c sec.");
            return false;
        }
        if (isMorphed(uuid)) unmorphPlayer(player);

        morphedPlayers.put(uuid, entityType);
        cooldowns.put(uuid, System.currentTimeMillis());

        if (hasLibsDisguises) applyDisguise(player, entityType);
        applyMobAbilities(player, entityType);

        player.setDisplayName("§8[§6" + formatMobName(entityType) + "§8] §f" + player.getName());
        player.setPlayerListName("§8[§6" + formatMobName(entityType) + "§8] §f" + player.getName());
        player.addPotionEffect(new PotionEffect(PotionEffectType.GLOWING, Integer.MAX_VALUE, 0, true, false));
        player.sendMessage("§a[MorphPlugin] Morphed into §e" + formatMobName(entityType) + "§a!");
        if (plugin.getConfig().getBoolean("settings.play-sound", true))
            player.playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1.2f);
        return true;
    }

    // Use reflection so code compiles without LibsDisguises dependency
    private void applyDisguise(Player player, EntityType entityType) {
        try {
            Class<?> disguiseApiClass = Class.forName("me.libraryaddict.disguise.DisguiseAPI");
            Class<?> disguiseTypeClass = Class.forName("me.libraryaddict.disguise.disguisetypes.DisguiseType");
            Class<?> mobDisguiseClass = Class.forName("me.libraryaddict.disguise.disguisetypes.MobDisguise");

            Method getType = disguiseTypeClass.getMethod("getType", EntityType.class);
            Object disguiseType = getType.invoke(null, entityType);
            if (disguiseType == null) return;

            Object disguise = mobDisguiseClass.getConstructor(disguiseTypeClass).newInstance(disguiseType);
            Method setReplaceSounds = mobDisguiseClass.getMethod("setReplaceSounds", boolean.class);
            setReplaceSounds.invoke(disguise, true);

            Class<?> disguiseInterface = Class.forName("me.libraryaddict.disguise.disguisetypes.Disguise");
            Method disguiseToAll = disguiseApiClass.getMethod("disguiseToAll", Player.class, disguiseInterface);
            disguiseToAll.invoke(null, player, disguise);
        } catch (Exception e) {
            plugin.getLogger().warning("[MorphPlugin] Disguise failed: " + e.getMessage());
        }
    }

    private void removeDisguise(Player player) {
        if (!hasLibsDisguises) return;
        try {
            Class<?> disguiseApiClass = Class.forName("me.libraryaddict.disguise.DisguiseAPI");
            Method undisguise = disguiseApiClass.getMethod("undisguiseToAll", Player.class);
            undisguise.invoke(null, player);
        } catch (Exception ignored) {}
    }

    private void applyMobAbilities(Player player, EntityType type) {
        List<BukkitTask> tasks = new ArrayList<>();
        removeAllPotionEffects(player);

        switch (type) {
            case BEE, BAT, PARROT, ALLAY -> {
                player.setAllowFlight(true);
                player.sendMessage("§b✦ §fFly!");
            }
            case PHANTOM -> {
                player.setAllowFlight(true);
                player.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, Integer.MAX_VALUE, 0, true, false));
                player.sendMessage("§b✦ §fFly + Night Vision!");
            }
            case GHAST -> {
                player.setAllowFlight(true);
                player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, Integer.MAX_VALUE, 1, true, false));
                player.sendMessage("§b✦ §fFly + Resistance!");
            }
            case BLAZE -> {
                player.setAllowFlight(true);
                player.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, Integer.MAX_VALUE, 0, true, false));
                player.sendMessage("§b✦ §fFly + Fire Immunity!");
            }
            case ENDER_DRAGON -> {
                player.setAllowFlight(true);
                player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, Integer.MAX_VALUE, 4, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, Integer.MAX_VALUE, 2, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.HEALTH_BOOST, Integer.MAX_VALUE, 9, true, false));
                player.sendMessage("§b✦ §fDragon Power!");
            }
            case WITHER -> {
                player.setAllowFlight(true);
                player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, Integer.MAX_VALUE, 3, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, Integer.MAX_VALUE, 1, true, false));
                player.sendMessage("§b✦ §fWither Power!");
            }
            case VEX -> {
                player.setAllowFlight(true);
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 2, true, false));
                player.sendMessage("§b✦ §fFly + Speed!");
            }
            case WARDEN -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, Integer.MAX_VALUE, 4, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, Integer.MAX_VALUE, 4, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.HEALTH_BOOST, Integer.MAX_VALUE, 14, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.DARKNESS, Integer.MAX_VALUE, 0, true, false));
                player.sendMessage("§b✦ §fYOU ARE THE WARDEN!");
            }
            case IRON_GOLEM -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, Integer.MAX_VALUE, 4, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, Integer.MAX_VALUE, 2, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.HEALTH_BOOST, Integer.MAX_VALUE, 9, true, false));
                player.sendMessage("§b✦ §fIron Golem Strength!");
            }
            case ENDERMAN -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 1, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, Integer.MAX_VALUE, 0, true, false));
                player.sendMessage("§b✦ §fSpeed + Night Vision! Sneak to teleport!");
                BukkitTask task = plugin.getServer().getScheduler().runTaskTimer(plugin, () -> {
                    if (!isMorphed(player.getUniqueId())) return;
                    if (player.isSneaking()) {
                        org.bukkit.block.Block target = player.getTargetBlock(null, 50);
                        if (target != null) {
                            player.teleport(target.getLocation().add(0, 1, 0));
                            player.getWorld().spawnParticle(Particle.PORTAL, player.getLocation(), 30);
                            player.playSound(player.getLocation(), Sound.ENTITY_ENDERMAN_TELEPORT, 1f, 1f);
                        }
                    }
                }, 0L, 15L);
                tasks.add(task);
            }
            case DOLPHIN -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.DOLPHINS_GRACE, Integer.MAX_VALUE, 0, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.WATER_BREATHING, Integer.MAX_VALUE, 0, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 1, true, false));
                player.sendMessage("§b✦ §fSwim Fast + Water Breathing!");
            }
            case SQUID, GLOW_SQUID -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.WATER_BREATHING, Integer.MAX_VALUE, 0, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, Integer.MAX_VALUE, 0, true, false));
                player.sendMessage("§b✦ §fWater Breathing + Night Vision!");
            }
            case AXOLOTL -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.WATER_BREATHING, Integer.MAX_VALUE, 0, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, Integer.MAX_VALUE, 1, true, false));
                player.sendMessage("§b✦ §fWater Breathing + Regen!");
            }
            case TURTLE -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.WATER_BREATHING, Integer.MAX_VALUE, 0, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, Integer.MAX_VALUE, 3, true, false));
                player.sendMessage("§b✦ §fWater + Shell Defense!");
            }
            case SPIDER, CAVE_SPIDER -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 1, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.NIGHT_VISION, Integer.MAX_VALUE, 0, true, false));
                if (type == EntityType.CAVE_SPIDER)
                    player.addPotionEffect(new PotionEffect(PotionEffectType.POISON, Integer.MAX_VALUE, 0, true, false));
                player.sendMessage("§b✦ §fSpeed + Night Vision" + (type == EntityType.CAVE_SPIDER ? " + Poison!" : "!"));
            }
            case ZOMBIE, ZOMBIE_VILLAGER, HUSK -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, Integer.MAX_VALUE, 0, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, Integer.MAX_VALUE, 0, true, false));
                if (type == EntityType.HUSK)
                    player.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, Integer.MAX_VALUE, 0, true, false));
                player.sendMessage("§b✦ §fStrength + Resistance!");
            }
            case SKELETON, STRAY -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 0, true, false));
                player.sendMessage("§b✦ §fSkeleton Speed!");
            }
            case WITCH -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.REGENERATION, Integer.MAX_VALUE, 0, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, Integer.MAX_VALUE, 0, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.WATER_BREATHING, Integer.MAX_VALUE, 0, true, false));
                player.sendMessage("§b✦ §fWitch Resistance!");
            }
            case RABBIT -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 2, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, Integer.MAX_VALUE, 5, true, false));
                player.sendMessage("§b✦ §fSpeed + Mega Jump!");
            }
            case HORSE, DONKEY, MULE -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 3, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, Integer.MAX_VALUE, 2, true, false));
                player.sendMessage("§b✦ §fSuper Speed + Jump!");
            }
            case WOLF -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 1, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, Integer.MAX_VALUE, 1, true, false));
                player.sendMessage("§b✦ §fSpeed + Strength!");
            }
            case SLIME, MAGMA_CUBE -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, Integer.MAX_VALUE, 4, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, Integer.MAX_VALUE, 1, true, false));
                if (type == EntityType.MAGMA_CUBE)
                    player.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, Integer.MAX_VALUE, 0, true, false));
                player.sendMessage("§b✦ §fMega Jump + Resistance!");
            }
            case GOAT -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, Integer.MAX_VALUE, 5, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, Integer.MAX_VALUE, 0, true, false));
                player.sendMessage("§b✦ §fMega Jump + Strength!");
            }
            case FROG -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.JUMP_BOOST, Integer.MAX_VALUE, 3, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.WATER_BREATHING, Integer.MAX_VALUE, 0, true, false));
                player.sendMessage("§b✦ §fHigh Jump + Water Breathing!");
            }
            case PIGLIN, PIGLIN_BRUTE -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, Integer.MAX_VALUE, 0, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, Integer.MAX_VALUE, 1, true, false));
                player.sendMessage("§b✦ §fFire Resistance + Strength!");
            }
            case STRIDER -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.FIRE_RESISTANCE, Integer.MAX_VALUE, 0, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 0, true, false));
                player.sendMessage("§b✦ §fFire Immune + Speed!");
            }
            case VILLAGER -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.HERO_OF_THE_VILLAGE, Integer.MAX_VALUE, 0, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.LUCK, Integer.MAX_VALUE, 0, true, false));
                player.sendMessage("§b✦ §fHero + Luck!");
            }
            case SNIFFER -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.LUCK, Integer.MAX_VALUE, 2, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.HEALTH_BOOST, Integer.MAX_VALUE, 4, true, false));
                player.sendMessage("§b✦ §fLuck + Extra Hearts!");
            }
            case RAVAGER -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, Integer.MAX_VALUE, 3, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, Integer.MAX_VALUE, 2, true, false));
                player.sendMessage("§b✦ §fBrute Strength + Defense!");
            }
            case POLAR_BEAR -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.STRENGTH, Integer.MAX_VALUE, 2, true, false));
                player.addPotionEffect(new PotionEffect(PotionEffectType.RESISTANCE, Integer.MAX_VALUE, 1, true, false));
                player.sendMessage("§b✦ §fBear Strength + Defense!");
            }
            default -> {
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, Integer.MAX_VALUE, 0, true, false));
                player.sendMessage("§b✦ §fBasic Speed!");
            }
        }
        morphTasks.put(player.getUniqueId(), tasks);
    }

    private void removeAllPotionEffects(Player player) {
        for (PotionEffect e : player.getActivePotionEffects())
            player.removePotionEffect(e.getType());
    }

    public boolean unmorphPlayer(Player player) {
        UUID uuid = player.getUniqueId();
        if (!isMorphed(uuid)) {
            player.sendMessage("§c[MorphPlugin] You are not morphed.");
            return false;
        }
        List<BukkitTask> tasks = morphTasks.getOrDefault(uuid, new ArrayList<>());
        for (BukkitTask t : tasks) t.cancel();
        morphTasks.remove(uuid);
        morphedPlayers.remove(uuid);

        removeDisguise(player);
        player.setDisplayName(player.getName());
        player.setPlayerListName(player.getName());
        removeAllPotionEffects(player);
        player.removePotionEffect(PotionEffectType.GLOWING);
        player.setAllowFlight(player.getGameMode() == GameMode.CREATIVE
                || player.getGameMode() == GameMode.SPECTATOR);
        player.sendMessage("§a[MorphPlugin] Returned to normal form!");
        if (plugin.getConfig().getBoolean("settings.play-sound", true))
            player.playSound(player.getLocation(), Sound.ENTITY_PLAYER_LEVELUP, 1f, 1.5f);
        return true;
    }

    public void unmorphAll() {
        for (UUID uuid : new HashSet<>(morphedPlayers.keySet())) {
            Player p = plugin.getServer().getPlayer(uuid);
            List<BukkitTask> tasks = morphTasks.getOrDefault(uuid, new ArrayList<>());
            for (BukkitTask t : tasks) t.cancel();
            if (p != null && p.isOnline()) {
                removeDisguise(p);
                p.setDisplayName(p.getName());
                p.setPlayerListName(p.getName());
                removeAllPotionEffects(p);
                p.setAllowFlight(p.getGameMode() == GameMode.CREATIVE || p.getGameMode() == GameMode.SPECTATOR);
                p.sendMessage("§e[MorphPlugin] Unmorphed.");
            }
        }
        morphedPlayers.clear();
        morphTasks.clear();
    }

    public boolean isMorphed(UUID uuid) { return morphedPlayers.containsKey(uuid); }
    public EntityType getMorphType(UUID uuid) { return morphedPlayers.get(uuid); }

    public boolean isOnCooldown(UUID uuid) {
        if (!cooldowns.containsKey(uuid)) return false;
        int ms = plugin.getConfig().getInt("settings.morph-cooldown", 5) * 1000;
        return (System.currentTimeMillis() - cooldowns.get(uuid)) < ms;
    }

    public long getRemainingCooldown(UUID uuid) {
        if (!cooldowns.containsKey(uuid)) return 0;
        int ms = plugin.getConfig().getInt("settings.morph-cooldown", 5) * 1000;
        return Math.max(0, (ms - (System.currentTimeMillis() - cooldowns.get(uuid))) / 1000);
    }

    public String formatMobName(EntityType type) {
        StringBuilder r = new StringBuilder();
        for (String w : type.name().replace("_", " ").split(" "))
            if (!w.isEmpty()) r.append(Character.toUpperCase(w.charAt(0))).append(w.substring(1).toLowerCase()).append(" ");
        return r.toString().trim();
    }

    public List<EntityType> getAvailableMobs() {
        List<EntityType> mobs = new ArrayList<>();
        List<String> blocked = plugin.getConfig().getStringList("blocked-mobs");
        for (EntityType t : EntityType.values())
            if (t.isAlive() && t.isSpawnable() && !blocked.contains(t.name()))
                mobs.add(t);
        return mobs;
    }
}
