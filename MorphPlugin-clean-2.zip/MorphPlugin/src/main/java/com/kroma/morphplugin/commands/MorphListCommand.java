package com.kroma.morphplugin.commands;

import com.kroma.morphplugin.MorphPlugin;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.EntityType;

import java.util.List;

public class MorphListCommand implements CommandExecutor {
    private final MorphPlugin plugin;
    public MorphListCommand(MorphPlugin plugin) { this.plugin = plugin; }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        List<EntityType> mobs = plugin.getMorphManager().getAvailableMobs();
        sender.sendMessage("§6=== Available Mobs (" + mobs.size() + ") ===");
        StringBuilder sb = new StringBuilder("§e");
        for (EntityType t : mobs) sb.append(t.name().toLowerCase()).append("§7, §e");
        sender.sendMessage(sb.toString());
        return true;
    }
}
